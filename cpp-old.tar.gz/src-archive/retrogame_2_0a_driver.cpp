/*******************************************************************************
	retro game - 2.0a
	build 07182018

	refresh the memory and implement blitting optimization techniques.
*******************************************************************************/
#include <SDL.h>
#include <stdio.h>
#include <string>

// global variables
const int nSCREEN_WIDTH = 640;
const int nSCREEN_HEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* surf_mainchar = NULL; // gStretchedSurface

// global functions
bool init();
bool loadMedia();
void terminate();
SDL_Surface* loadSurface(std::string path);

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("failed to initialize\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("failed to loadMedia");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;

			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
					{
						bQuit = true;
					}
				}

				// apply & stretch image
				SDL_Rect stretchRect;
				stretchRect.x = 0;
				stretchRect.y = 0;
				stretchRect.w = nSCREEN_WIDTH;
				stretchRect.h = nSCREEN_HEIGHT;
				SDL_BlitScaled(surf_mainchar, NULL, gScreenSurface, &stretchRect);

				// update surface
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}

	terminate();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize");
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("Retro Game - v2.0a", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nSCREEN_WIDTH, nSCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("failed to create window");
			bSuccess = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}

	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	surf_mainchar = loadSurface("assets/npc0.bmp");
	if (surf_mainchar == NULL)
	{
		printf("failed to load surface (surf_mainchar)");
		bSuccess = false;
	}

	return bSuccess;
}

SDL_Surface* loadSurface(std::string path)
{
	// final, optimized surface
	SDL_Surface* optimizedSurface = NULL;

	// load image @ path
	SDL_Surface* loadedSurface = SDL_LoadBMP(path.c_str());
	if (loadedSurface == NULL)
	{
		printf("failed to load surface (loadedSurface)");
	}
	else
	{
		// convert surface to screen format
		optimizedSurface = SDL_ConvertSurface(loadedSurface, gScreenSurface->format, NULL);
		if (optimizedSurface == NULL)
		{
			printf("failed to optimized image (optimizedSurface)");
		}

		// get rid of old surface
		SDL_FreeSurface(loadedSurface);
	}

	return optimizedSurface;
}

void terminate()
{
	SDL_FreeSurface(surf_mainchar);
	surf_mainchar = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}