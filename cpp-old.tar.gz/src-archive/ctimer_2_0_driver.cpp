/*

	CTIMER - 2.0 release
	Build:	 04072018

	new and improved CTIMER app 2.0. app outputs a timer every
	second. user stops the timer at the press of a button at which
	point the app will output the final seconds elapsed and
	prompt the user to start again or quit.

*/
#include <iostream>
#include <ctime>
#include <string>
#include <Windows.h>
using namespace std;

int main(int argn, char* argc[]) {

	cout << "\t\tCTIMER 2.0\n\t Build 04072018" << endl;

	string sCMD;
	double dSecEl;
	clock_t ctStart, ctCurrent;
	bool bRunning = true;
	bool bTiming = false;

	while (bRunning) {

		cout << "ENTER 'start OR 'quit': ";
		cin >> sCMD; cout << endl;

		if (sCMD == "start") {
			bTiming = true;
			ctStart = clock();

			while (bTiming) {
				
				ctCurrent = clock();
				dSecEl = (double)(ctCurrent - ctStart) / CLOCKS_PER_SEC;
				
				cout << "SEC ELAPSED: " << dSecEl << endl;

				//
				//	this is just c&paste from one of javidx9's olc games. these also work:	- GetAsyncKeyState(0x51)	<- 0x51 is hex value for virtual key code 'Q'
				if (GetAsyncKeyState((unsigned short)'Q') & 0x8000)						//	- GetAsyncKeyState('Q')
					bTiming = false;													//	i think he coded it this way because: (unsigned) is less mem,
																						//	0x8000 - i think the 8 is designated the 'high bit' and its value
			}																			//	indicates the state of the key (pressed, toggled)

		}

		else if (sCMD == "quit")
			bRunning = false;

	}

	return 0;
}