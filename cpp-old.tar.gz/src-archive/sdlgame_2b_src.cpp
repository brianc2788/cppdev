/*******************************************************************************
	sdl game - 2b
	build 08022018
*******************************************************************************/
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* tex_mChar = NULL;

bool init()
{
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO_) < 0)
	{
		printf("failed to initialize SDL [video]. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		window = SDL_CreateWindow("sdl game - 2b", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, \
			nSCREENWIDTH, nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL)
			{
				printf("failed to create renderer. %s\n", SDL_GetError());
				bSuccess = false;
			}
			else
			{
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags))
				{
					printf("failed to initialize SDL_image. %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;
	tex_mChar = loadTexture("NPC1.png");
	if (tex_mChar == NULL)
	{
		printf("loadMedia() failed to load tex_mChar.\n");
		bSuccess = false;
	}
	return bSuccess;
}

void close()
{
	SDL_DestroyTexture(tex_mChar);
	tex_mChar = NULL;

	SDL_DestroyRenderer(renderer);
	renderer = NULL;

	SDL_DestroyWindow(window);
	window = NULL;

	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture(std::string img_path)
{
	SDL_Texture* newTexture = NULL;
	SDL_Surface* loadImage = IMG_Load(img_path.c_str());
	if (loadImage == NULL)
	{
		printf("failed to load image to surface. %s\n", IMG_GetError());
	}
	else
	{
		newTexture = SDL_CreateTextureFromSurface(renderer, loadImage);
		if (newTexture == NULL)
		{
			printf("failed to create texture from surface. %s\n", SDL_GetError());
		}
		else
		{

		}
	}
}