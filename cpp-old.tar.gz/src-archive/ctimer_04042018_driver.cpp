﻿/*																			  *//*

	CTIMER - v04042018
	
	simple timer using <ctime>

	DESCRIPTION:
	ultimately, it stores the value returned by clock(), essentially recording the time when it is
	initialized. later, clock() is called to get the updated time and clock_t type overwrites itself
	to equal the current time minus its old value. thus, it equals the difference.
	use of getchar() halts the process so control program flow as to when clock() is called and the time
	is gotten.

	TODO:
		- tried outputting minutes but got too many errors so i will leave this code as-is and create
		  separate project.
		- want to use MM:SS.S format

	SIDENOTE: this is why every time i used to call time() from this library
	(to use with srand to get a random number. it calls the time function to return a value (number of
	seconds since midnight 00:00 of january 1st, 1970... just a fun fact) to use with its random number
	algorithm.. phew)

	i always got a compiler error(warning) for converting from type time_t to an integer.
	should manually cast the variable when using it.

	complied in unicode because tried to print japanese characters but failed.

	PROJECT IDEAS:
		time how long it takes to type a string. output difference in attempts.
		many possibilities...

*/																			  /**/

// having fun with C typedefs and guards. bunch of meaningless crap. seems to take longer to compile?
#define EXIT_SUCCESS 1
#define EXIT_FAILURE 0

#include <iostream>
#include <ctime>		// using clock_t, clock(), CLOCKS_PER_SEC
#include <cstdlib>		// just for fun

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif
#ifndef EXIT_FAILURE
#define EXIT_FAILURE 1
#endif
#ifndef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC
int blah_blah_blah;
#endif

using namespace std;

int main() {

	cout << "CTIMER - version 04042018" << endl << endl;

	clock_t ctTime;
	char yn;
	bool bRunning = true;

	while (bRunning) {

		cout << "press enter to start the timer..." << endl;
		getchar();

		ctTime = clock();

		cout << "timer started. press enter to stop..." << endl;
		getchar();

		ctTime = clock() - ctTime;

		cout << "seconds elapsed: " << (float)ctTime / CLOCKS_PER_SEC << endl << endl;

		cout << "start new timer? (y/n): ";
		cin >> yn; cout << endl << endl;
		cin.ignore();	// flush(?) the istream.

		switch (yn) {
		case 'n':
			bRunning = false;
		default:
			continue;	// always running unless 'n'.
		}

	}

	cout << "quitting...";
	getchar();
	return EXIT_SUCCESS;
}