//
// testing. 123...
//

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <cstdlib>
#include <stdio.h>

int SCREENW = 640;
int SCREENH = 480;

SDL_Window* window = NULL;

bool init() {
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize video. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("sdl scrap1", SDL_WINDOWPOS_UNDEFINED,
			SDL_WINDOWPOS_UNDEFINED, SCREENW, SCREENH,
			SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {

		}
	}
}

int func1(int n1)