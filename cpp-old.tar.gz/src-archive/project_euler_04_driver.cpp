/******************************************************************************
	Project Euler - Problem 04
	6-28-2018

	From: https://projecteuler.net/problem=4

	"A palindromic number reads the same both ways. The largest palindrome
	made from the product of two 2-digit numbers is 9009 = 91 � 99.
	Find the largest palindrome made from the product of two 3-digit numbers."

	largest product of 2 3-digit numbers: (999x999) 998001
	logically, should get 90009.
******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

int getHund(int entry);

int main(int argc, char* argv[])
{
	int nNum1 = 333;
	int nArr1[3] = { 0,0,0 };

	nArr1[0] = getHund(nNum1);

	cout << nArr1[0] << endl;

	getchar();
	return 0;
}

int getHund(int entry)
{
	bool bDiv = false;

	while (!bDiv)
	{
		if (entry % 100 == 0)
			return (entry / 100);
		else
			entry -= 1;
	}
}