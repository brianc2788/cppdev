/******************************************************************************
							Find Pi
						 Build 06242018

	- Displays Pi to the nearest decimal specified by user input.
	- Up to 10 digits (9 decimal places).

******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <iomanip>
using namespace std;

int main(int argc, char* argv[])
{
	// variable declarations
	const float cfPi = 3.141592653;
	int nUserInput = 1;
	bool bQuit = false;

	printf("---- Find PI ----");
	printf("\nDisplay PI up to 10 digits");
	printf("\nEnter 1 - 10 to display PI or 0 to exit application");

	while (!bQuit)
	{
		printf("\nEnter 1-10 or 0 to exit: ");
		cin >> nUserInput; cout << endl;

		if (nUserInput < 1)
		{
			bQuit = true;
		}
		else if (nUserInput > 10)
		{
			printf("Enter a number 1 - 10 or 0 to quit");
			break;
		}

		cout << setprecision(nUserInput) << cfPi << endl << endl;
	}

	printf("\n\nQuitting application. Press any key to exit...");
	cin.ignore();
	getchar();
	return 0;
}