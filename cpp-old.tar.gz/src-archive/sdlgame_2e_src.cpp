/*******************************************************************************
	SDL Game - 2e
	Build 08042018

	update from 2d:
	slightly further optimized. removed rendundant variables (int nPlayerPosX,
	nPlayerPosY). happy with it. proud of my loop and nested loop to render
	the floor. this is the way to go. original code by... me.
	original "game", by.... me.
*******************************************************************************/
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* tex_floor32 = NULL;
SDL_Texture* tex_npc2 = NULL;

bool init()
{
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize SDL [video flag]. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		window = SDL_CreateWindow("SDL Game - 2e", SDL_WINDOWPOS_UNDEFINED, \
									SDL_WINDOWPOS_UNDEFINED, nSCREENWIDTH, \
									nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL)
			{
				printf("failed to create renderer. %s\n", SDL_GetError());
				bSuccess = false;
			}
			else
			{
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags))
				{
					printf("failed to initialize sdl_image. %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

SDL_Texture* loadTexture(std::string img_path)
{
	SDL_Texture* newTexture = NULL;
	SDL_Surface* loadSurface = IMG_Load(img_path.c_str());
	if (loadSurface == NULL)
	{
		printf("failed to load image to surface. %s\n", IMG_GetError());
	}
	else
	{
		newTexture = SDL_CreateTextureFromSurface(renderer, loadSurface);
		if (newTexture == NULL)
		{
			printf("failed to create texture from surface. %s\n", SDL_GetError());
		}

		SDL_FreeSurface(loadSurface);
	}
	return newTexture;
}

bool loadMedia()
{
	bool bSuccess = true;

	tex_floor32 = loadTexture("floor32.png");
	if (tex_floor32 == NULL)
	{
		printf("failed to load floor32.png.");
		bSuccess = false;
	}
	else
	{
		tex_npc2 = loadTexture("npc1.png");
		if (tex_npc2 == NULL)
		{
			printf("failed to load npc1.png.");
			bSuccess = false;
		}
	}
	return bSuccess;
}

void close()
{
	SDL_DestroyTexture(tex_floor32);
	tex_floor32 = NULL;

	SDL_DestroyTexture(tex_npc2);
	tex_npc2 = NULL;

	SDL_DestroyRenderer(renderer);
	renderer = NULL;

	SDL_DestroyWindow(window);
	window = NULL;

	IMG_Quit();
	SDL_Quit();
}

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("init() has failed.\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("loadMedia() has failed.\n");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;
			SDL_Rect rPlayer = { 304, 224, 32, 32 };

			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.key.keysym.sym == SDLK_UP && rPlayer.y > 0)
						rPlayer.y -= 5;
					else if (event.key.keysym.sym == SDLK_DOWN && rPlayer.y < 448)
						rPlayer.y += 5;
					else if (event.key.keysym.sym == SDLK_LEFT && rPlayer.x > 0)
						rPlayer.x -= 5;
					else if (event.key.keysym.sym == SDLK_RIGHT && rPlayer.x < 608)
						rPlayer.x += 5;
				}

				SDL_RenderClear(renderer);

				SDL_Rect rFloor32 = { 0, 0, 32, 32 };
				for (int y = 0; y <= 15; y++)
				{
					for (int x = 0; x <= 20; x++)
					{
						SDL_RenderCopy(renderer, tex_floor32, NULL, &rFloor32);
						rFloor32.x += 32;
					}
					rFloor32.x = 0;
					rFloor32.y += 32;
				}

				SDL_RenderCopy(renderer, tex_npc2, NULL, &rPlayer);

				SDL_RenderPresent(renderer);
			}
		}
	}
	close();
	return 0;
}