/*******************************************************************************
	note-taker - v1.0

	simple note-taking application. type in a note, it will be recorded in a
	text file that the application can also print back to the user. also
	records a date and time stamp.
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <ctime>
#include <Windows.h>

int add(int* ptrnum)
{
	int number = *ptrnum + 13;
	return number;
};

int main(int argc, char* argv[])
{
	int num = 12;
	int* pnum = &num;

	std::cout << add(pnum) << std::endl;
	std::cout << *pnum << std::endl << num << std::endl;

	getchar();
	return 0;
}