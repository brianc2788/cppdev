/******************************************************************************
					Retro Game - v1.0a
					Build 06052018

	Created a simple program from scratch. Completely original concept, design,
	and code. Almost can't believe it worked, but it works exactly like how
	I wanted. My only concern is that there should be no memory leaks, which
	there doesn't seem to be any. Keeping this project for future reference.

	Directions: Use arrow keys to move on-screen avatar/sprite.

	NOTES: added draw routine for floor tiles but application fails to
		   execute properly more than once.
******************************************************************************/
#include <SDL.h>
#include <stdio.h>
#include <string>

int main(int argc, char* argv[])
{
	SDL_Init(SDL_INIT_VIDEO);
	SDL_Window* gWindow = NULL;
	gWindow = SDL_CreateWindow("Retro Game - v1.0a", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, SDL_WINDOW_SHOWN);
	SDL_Surface* gScreenSurface = NULL;
	gScreenSurface = SDL_GetWindowSurface(gWindow);
	SDL_Surface* surf_player = NULL;
	surf_player = SDL_LoadBMP("assets/NPC0.bmp");
	SDL_Surface* surf_floor = NULL;
	SDL_Event event;

	int floorX = 0;
	int floorY = 0;
	SDL_Rect rectFloor = { floorX, floorY, NULL, NULL };
	surf_floor = SDL_LoadBMP("assets/floor32.bmp");
	for (int x = 0; x < 15; x++)
	{
		for (int y = 0; y < 20; y++)
		{
			SDL_BlitSurface(surf_floor, NULL, gScreenSurface, &rectFloor);
			floorY += 32;
		}
		SDL_BlitSurface(surf_floor, NULL, gScreenSurface, &rectFloor);
		floorX += 32;
	}

	int playerposX = 304;
	int playerposY = 224;
	SDL_Rect rect_player = { playerposX, playerposY,0,0 };

	bool bQuit = false;

	while (!bQuit)
	{
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
				bQuit = true;
			else if (event.key.keysym.sym == SDLK_UP && playerposY > 0)
			{
				playerposY -= 5;
			}
			else if (event.key.keysym.sym == SDLK_DOWN && playerposY < 448)
			{
				playerposY += 5;
			}
			else if (event.key.keysym.sym == SDLK_LEFT && playerposX > 0)
			{
				playerposX -= 5;
			}
			else if (event.key.keysym.sym == SDLK_RIGHT && playerposX < 608)
			{
				playerposX += 5;
			}
		}
		rect_player = { playerposX,playerposY,0,0 };
		SDL_BlitSurface(surf_player, NULL, gScreenSurface, &rect_player);
		SDL_UpdateWindowSurface(gWindow);
	}

	SDL_FreeSurface(surf_player);
	surf_player = NULL;

	SDL_FreeSurface(surf_floor);
	surf_floor = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
	return 0;
}

// abandon-ware?
void drawBackground()
{
	SDL_Surface* surf_floor = NULL;

}