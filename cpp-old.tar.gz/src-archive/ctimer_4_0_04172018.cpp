/*

	CTIMER - Version 4.0
	Build 04172018

	creates a console screen buffer and writes directly to it.

*/
#include <iostream>
#include <ctime>
#include <Windows.h>
using namespace std;

int nScreenWidth = 40;
int nScreenHeight = 20;

wchar_t* pScreen = new wchar_t[nScreenWidth*nScreenHeight];
HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
DWORD dwBytesWritten = 0;

void timer();

int main(int argc, char* argv[]) {

	for (int x = 0; x < nScreenWidth*nScreenHeight; x++) { pScreen[x] = L' '; }
	SetConsoleTextAttribute(hConsole, 0x0070); // 0x00[BG][FG], 7 - white, 0 - black
	SetConsoleScreenBufferSize(hConsole, { 40,20 });
	SetConsoleActiveScreenBuffer(hConsole);

	bool bRunning = true;
	while (bRunning) {

		swprintf_s(&pScreen[40], 12, L"Press ENTER");

		if (GetAsyncKeyState((unsigned char)'\r')) {
			timer();
			bRunning = false;
		}

		WriteConsole(hConsole, pScreen, nScreenWidth*nScreenHeight, &dwBytesWritten, NULL);		

	}

	CloseHandle(hConsole);
	return 0;
}

void timer() {
	clock_t ctStart = clock();
	clock_t ctCurrent;
	
	bool bTiming = true;
	while (bTiming) {

		ctCurrent = clock();

		swprintf_s(&pScreen[160], 20, L"Press Q to stop");

		swprintf_s(&pScreen[200], 40, L"SEC ELAPSED: %f", (float)(ctCurrent - ctStart) / CLOCKS_PER_SEC);

		if (GetAsyncKeyState((unsigned char)'Q'))
			bTiming = false;

		WriteConsole(hConsole, pScreen, nScreenWidth*nScreenHeight, &dwBytesWritten, NULL);

	}

}