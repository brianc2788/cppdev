/*******************************************************************************
	Project Euler - Problem 17
	build 08102018

	from: https://projecteuler.net/problem=17

	If the numbers 1 to 5 are written out in words: one, two, three, four, five,
	then there are 3 + 3 + 5 + 4 + 4 = 19 letters used in total.
	If all the numbers from 1 to 1000 (one thousand) inclusive were written out
	in words, how many letters would be used?

	NOTE: Do not count spaces or hyphens.
	For example, 342 (three hundred and forty-two) contains 23 letters and
	115 (one hundred and fifteen) contains 20 letters. The use of "and" when
	writing out numbers is in compliance with British usage.

	8-10-18 : converts a digit up to/including ninety nine to a string.
			  still need to get to 1000 and add upp the characters in
			  the string(s).
*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;

std::string sConvertDigitSingle(int number_in);
std::string ConvertDigit(int nNumIn);

int main(int argc, char* argv[])
{
	printf("Project Euler - Problem 17\n");
	printf("Enter a digit and application will return it in a string.\n");

	bool bQuit = false;
	int nEntry;

	while (!bQuit)
	{
		printf("Enter: ");

		std::cin >> nEntry; std::cout << std::endl;

		if (nEntry <= 0)
			bQuit = true;
		else
			std::cout << ConvertDigit(nEntry) << std::endl;

		std::string sNumString = ConvertDigit(nEntry);
		int nCharCount = 0;

		for (int x = 0; x < sNumString.length(); x++)
		{
			if (sNumString[x] == ' ')
				continue;
			else
				nCharCount++;
		}

		printf("Number of characters in the string: %d\n", nCharCount);
	}

	getchar();
	return 0;
}

std::string sConvertDigitSingle(int number_in)
{
	std::string number_out;

	if (number_in == 1)
		number_out = "one";
	else if (number_in == 2)
		number_out = "two";
	else if (number_in == 3)
		number_out = "three";
	else if (number_in == 4)
		number_out = "four";
	else if (number_in == 5)
		number_out = "five";
	else if (number_in == 6)
		number_out = "six";
	else if (number_in == 7)
		number_out = "seven";
	else if (number_in == 8)
		number_out = "eight";
	else if (number_in == 9)
		number_out = "nine";

	return number_out;
}

std::string ConvertDigit(int nNumIn)
{
	std::string sNumOut;

	// 1-9
	if (nNumIn < 10)
		sNumOut = sConvertDigitSingle(nNumIn);
	// 10-19
	else if (nNumIn > 10 && nNumIn < 20)
	{
		if (nNumIn == 10)
			sNumOut = "ten";
		else if (nNumIn == 11)
			sNumOut = "eleven";
		else if (nNumIn == 12)
			sNumOut = "twelve";
		else if (nNumIn == 13)
			sNumOut = "thirteen";
		else if (nNumIn == 15)
			sNumOut = "fifteen";
		else
		{
			sNumOut = sConvertDigitSingle((nNumIn - 10));
			sNumOut.append("teen");
		}
	}
	// 20-29
	else if (nNumIn >= 20 && nNumIn < 30)
	{
		sNumOut = "twenty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 20)));
	}
	// 30-39
	else if (nNumIn >= 30 && nNumIn < 40)
	{
		sNumOut = "thirty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 30)));
	}
	// 40-49
	else if (nNumIn >= 40 && nNumIn < 50)
	{
		sNumOut = "forty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 40)));
	}
	// 50-59
	else if (nNumIn >= 50 && nNumIn < 60)
	{
		sNumOut = "fifty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 50)));
	}
	// 60-69
	else if (nNumIn >= 60 && nNumIn < 70)
	{
		sNumOut = "sixty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 60)));
	}
	// 70 -79
	else if (nNumIn >= 70 && nNumIn < 80)
	{
		sNumOut = "seventy ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 70)));
	}
	// 80-89
	else if (nNumIn >= 80 && nNumIn < 90)
	{
		sNumOut = "eighty ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 80)));
	}
	// 90-99
	else if (nNumIn >= 90 && nNumIn < 100)
	{
		sNumOut = "ninety ";
		sNumOut.append(sConvertDigitSingle((nNumIn - 90)));
	}

	return sNumOut;
}


class NumtoString
{
public:
	NumtoString() {};
	~NumtoString() {};

	string ConvertNum(int num_in)
	{
		if (num_in >= 100)
			;
		else
			Convert_Hund(num_in);

		if (num_in >= )
	}

	string Convert_Hund(int nWholeNum)
	{
		if (nWholeNum >= 900)
	}

	string Convert_Ten(int nWholeNum)
	{

	}

	string Convert_One(int nWholeNum)
	{

	}

private:
	string sHund;
	string sTen;
	string sOne;
	string sComplete;
};
