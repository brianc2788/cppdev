#include "eng_esp_translator_dictionary_1_0.h"

std::string getSpan(std::string EngIn)
{
	if (EngIn == "house")
	{

	}
}