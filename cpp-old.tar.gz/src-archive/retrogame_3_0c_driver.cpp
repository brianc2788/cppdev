/*******************************************************************************
	retro game - v3.0c
	build 07282018

	same as 3.0a & 3.0b. rewritten for practice.
	also, fixed random error at loadSurface() from 3.0b.
	read access violation.
*******************************************************************************/
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

// global variables
const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* surface_mainchar = NULL;

// global functions
bool init();
bool loadMedia();
void term();
SDL_Surface* loadSurface(std::string img_path);

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("init() failed.\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("loadMedia() failed.\n");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;
			int playerposX = 304;
			int playerposY = 224;
			SDL_Rect rect_player = { playerposX, playerposY, NULL, NULL };

			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
					{
						bQuit = true;
					}
					else if (event.key.keysym.sym == SDLK_UP && playerposY > 0)
					{
						playerposY -= 5;
					}
					else if (event.key.keysym.sym == SDLK_DOWN && playerposY < 448)
					{
						playerposY += 5;
					}
					else if (event.key.keysym.sym == SDLK_LEFT && playerposX > 0)
					{
						playerposX -= 5;
					}
					else if (event.key.keysym.sym == SDLK_RIGHT && playerposX < 608)
					{
						playerposX += 5;
					}
				}
				rect_player = { playerposX, playerposY, NULL, NULL };
				SDL_BlitSurface(surface_mainchar, NULL, gScreenSurface, &rect_player);
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}
	printf("exited main loop... terminating application.\n");
	SDL_Delay(3000);
	term();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("retro game - v3.0c", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			nSCREENWIDTH, nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			int imgFlags = IMG_INIT_PNG;
			if (!IMG_Init(imgFlags) & imgFlags)
			{
				printf("failed to initialize image flags. %s\n", IMG_GetError());
				bSuccess = false;
			}
			else
			{
				gScreenSurface = SDL_GetWindowSurface(gWindow);
			}
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	surface_mainchar = loadSurface("assets/NPC3.png");
	if (surface_mainchar == NULL)
	{
		printf("failed to load image 'mainchar'. %s\n", IMG_GetError());
		bSuccess = false;
	}
	return bSuccess;
}

SDL_Surface* loadSurface(std::string img_path)
{
	SDL_Surface* opt_img = NULL;
	SDL_Surface* load_img = IMG_Load(img_path.c_str());
	if (load_img == NULL)
	{
		printf("failed to load image. %s\n", IMG_GetError());
	}
	else
	{
		opt_img = SDL_ConvertSurface(load_img, gScreenSurface->format, NULL);
		if (opt_img == NULL)
		{
			printf("failed to optimize image. %s\n", IMG_GetError());
		}
		SDL_FreeSurface(load_img);
	}
	return opt_img;
}

void term()
{
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_FreeSurface(gScreenSurface);
	gScreenSurface = NULL;

	SDL_FreeSurface(surface_mainchar);
	surface_mainchar = NULL;

	SDL_Quit();
}