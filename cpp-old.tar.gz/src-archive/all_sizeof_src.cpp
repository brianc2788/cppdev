/*
	print size of all datatypes [that i know of/can think of].
*/

#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {

	printf("Your PCs values are:\n\n");

	// practicing printf and C
	printf("Integer:\t%d Bytes\tBits: %d\n", sizeof(int), (sizeof(int) * 8));
	printf("Unsigned:\t%d Bytes\tBits: %d\n", sizeof(unsigned), (sizeof(unsigned) * 8));
	printf("Short:\t\t%d Bytes\tBits: %d\n", sizeof(short), (sizeof(short) * 8));
	printf("Unsigned Short: %d Bytes\tBits: %d\n\n", sizeof(unsigned short), (sizeof(unsigned short) * 8));

	printf("Floating-Point:\t\t%d Bytes   Bits: %d\n", sizeof(float), (sizeof(float) * 8));
	printf("Double Floating-Point: %d Bytes   Bits: %d\n\n", sizeof(double), (sizeof(double) * 8));

	printf("Char:\t\t%d Byte   Bits: %d\n", sizeof(char), (sizeof(char) * 8));
	printf("Unsigned Char:\t%d Bytes   Bits: %d\n", sizeof(unsigned char), (sizeof(unsigned char) * 8));
	printf("String:\t\t%d Bytes   Bits: %d\n", sizeof(string), (sizeof(string) * 8));

	getchar();
	return 0;
}