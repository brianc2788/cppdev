/*

	hangman without the hangman

*/
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

	string sHiddenWord = "DOORKNOB";
	string sDisplayWord[sizeof(sHiddenWord)];

	for (int x = 0; x < 8; x++) {
		sDisplayWord[x] = '_';
	}


	bool Game = true;

	while (Game) {

		cout << setw(12);
		for (int x = 0; x < 8; x++) {
			cout << sDisplayWord[x] << setw(2);
		}

		char cLetterGuess;

		cout << endl << endl << "enter a letter: ";
		cin >> cLetterGuess; cout << endl;

		for (int x = 0; x < 8; x++) {
			if (cLetterGuess == sHiddenWord[x]) {
				sDisplayWord[x] = sHiddenWord[x];
			}
		}

	}

	cin.ignore();
	getchar();
	return 0;
}