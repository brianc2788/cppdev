/*
	working with SDL in VC++
*/
#include "SDL.h"
#include <stdio.h>

const int nScreenWidth = 640;
const int nScreenHeight = 480;

int main(int argc, char*argv[])
{
	SDL_Init(SDL_INIT_EVERYTHING);

	SDL_Delay(5000);

	SDL_Quit();

	return 0;
}