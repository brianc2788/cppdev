﻿/******************************************************************************
	English - Espanol Translator - v1.0
	Build 0629108

	i guess it's more of a dictionary due to the nature of single-word
	entries.

******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

// forword function declarations
void eng_esp();
void esp_eng();

enum MenuOptions
{
	Quit = 0,
	English = 1,
	Español = 2
};

int main(int argc, char* argv[])
{
	int nMenuOption;
	bool bQuit = false;

	printf("English - Español Translator - v1.0a\n");

	while (!bQuit)
	{
		printf("1 - Enter word in English\n2 - Entrar en español\n0 - Quit\n\nEnter: ");
		cin >> nMenuOption; cout << endl << endl;

		if (nMenuOption == English)
		{
			eng_esp();
		}
		else if (nMenuOption == Español)
		{
			esp_eng();
		}
		else if (nMenuOption == Quit)
		{
			bQuit = true;
			break;
		}
	}

	getchar();
	return 0;
}

void eng_esp()
{
	string sEngEntry;
	bool bSuccess = false;

	while (!bSuccess)
	{
		cout << "Enter word in English: ";
		cin >> sEngEntry; cout << endl;

		if (sEngEntry == "house")
		{
			cout << sEngEntry << " en Espanol: casa\n\n";
			bSuccess = true;
		}
		else
		{
			printf("Unrecognized entry... Try again.\n");
		}
	}

}

void esp_eng()
{
	string sEspEntry;
	bool bSuccess = false;

	while (!bSuccess)
	{
		cout << "Entrar palabra en Espanol: ";
		cin >> sEspEntry; cout << endl;

		if (sEspEntry == "casa")
		{
			cout << sEspEntry << " en Ingles: house\n\n";
			bSuccess = true;
		}
		else
		{
			printf("Unrecognized entry... Try again.\n");
		}
	}
}