/* ALL SIZEOF - Ver 2 */
/* written by user5260 */
// description: prints sizes of a few common
//				datatypes in bits and bytes to the terminal
//				for user reference. useful for seeing how
//				much memory your specific PC allocates for
//				each.
// date created: February 11, 2021
// 
// NOTES:
// this console application/shell script
// correctly prints most common datatypes' size
// in bits and bytes. original version passed
// sizeof() as a int ("%d") flag through printf(),
// while paired incorrectly with sizeof(), which
// returns a datatype of unsigned long rather than
// int.
// part of recent exersizes to better familiarize
// myself with printf() and scanf(); the main I/O
// in C.
#include <stdio.h>

int main(int argc, char* argv[]) {
	printf("\t*| All SizeOf - V2 |*\n\n");
	printf("Your computer stores data as the following:\n");

	printf("Integer:\t%lu bits - %lu bytes\n", (sizeof(int) / 8.0f), sizeof(int)); // int
	printf("Char:\t%lu bits - %lu bytes\n", (sizeof(char) / 8.0f), sizeof(char)); // char

	printf("\nPress ENTER  to exit...");
	getchar();
	return 0;
}