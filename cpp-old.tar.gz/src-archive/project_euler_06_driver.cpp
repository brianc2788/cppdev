﻿/******************************************************************************
	Project Euler - Problem 06

	From: https://projecteuler.net/problem=6

	"The sum of the squares of the first ten natural numbers is,
	1^2 + 2^2 + ... + 10^2 = 385
	The square of the sum of the first ten natural numbers is,
	(1 + 2 + ... + 10)2 = 55^2 = 3025
	Hence the difference between the sum of the squares of the first ten
	natural numbers and the square of the sum is 3025 − 385 = 2640.
	Find the difference between the sum of the squares of the first one
	hundred natural numbers and the square of the sum."

	answer: 25164150

******************************************************************************/
#include <iostream>
#include <stdio.h>
using namespace std;

int sumofSquares(int quantity);
int squareofSum(int quantity);

int main(int argc, char* argv[])
{
	printf("Sum of Squares (10): %d\n", sumofSquares(10));
	printf("Square of the sum (10): %d\n", squareofSum(10));
	printf("Difference of the sums: %d\n\n", (squareofSum(10) - sumofSquares(10)));

	printf("Sum of Squares (100): %d\n", sumofSquares(100));
	printf("Square of the sum (100): %d\n", squareofSum(100));
	printf("Difference of the sums: %d\n", (squareofSum(100) - sumofSquares(100)));

	getchar();
	return 0;
}

int sumofSquares(int quantity)
{
	int nSumofSquares = 0;

	for (int x = 1; x <= quantity; x++)
	{
		nSumofSquares += (x*x);
	}

	return nSumofSquares;
}

int squareofSum(int quantity)
{
	int nSquareofSum = 0;

	for (int x = 1; x <= quantity; x++)
	{
		nSquareofSum += x;
	}

	nSquareofSum = (nSquareofSum*nSquareofSum);

	return nSquareofSum;
}