////
//	sdl warmup 3
////
#include <SDL.h>
#include <SDL_image.h>
#include <cstdlib>
#include <stdio.h>
#include <string>

int SCREENW = 640;
int SCREENH = 480;

SDL_Window* win1 = NULL;
SDL_Renderer* renderer1 = NULL;
SDL_Texture* tex_floortile = NULL;
SDL_Texture* tex_npc = NULL;

bool init();
bool loadMedia();
SDL_Texture* loadTexture(std::string img_path);
void close();

int main(int argc, char* argv[]) {

	return 0;
}

bool init() {
	bool bSuccess = true;
	if (!SDL_Init(SDL_INIT_VIDEO)) {
		printf("failed to initialize SDL. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		win1 = SDL_CreateWindow("sdl wu3", SDL_WINDOWPOS_UNDEFINED,
			SDL_WINDOWPOS_UNDEFINED, SCREENW,
			SCREENH, SDL_WINDOW_SHOWN);
		if (win1 == NULL) {
			printf("failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			renderer1 = SDL_CreateRenderer(win1, -1, SDL_RENDERER_ACCELERATED);
			if (renderer1 == NULL) {
				printf("failed to create renderer. SDL Error: %s\n", SDL_GetError());
				bSuccess = false;
			}
			else {
				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags)) {
					printf("failed to initialize SDL_image. IMG Error: %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;
	tex_floortile = loadTexture("assets/floor32.png");
	if (tex_floortile == NULL) {
		printf("failed to load texture floortile.\n");
		bSuccess = false;
	}
	else {
		tex_npc = loadTexture("assets/npc1.png");
		if (tex_npc == NULL) {
			printf("failed to load texture npc.\n");
			bSuccess = false;
		}
	}
	return bSuccess;
}

SDL_Texture* loadTexture(std::string img_path) {
	SDL_Texture* newTexture = NULL;
	SDL_Surface* loadSurface = IMG_Load(img_path.c_str());
	if (loadSurface == NULL) {
		printf("failed to load surface. IMG Error: %s\n", IMG_GetError());
	}
	else {
		newTexture = SDL_CreateTextureFromSurface(renderer1, loadSurface);
		if (newTexture == NULL) {
			printf("failed to create texture from surface. SDL Error: %s\n", SDL_GetError());
		}
	}
}