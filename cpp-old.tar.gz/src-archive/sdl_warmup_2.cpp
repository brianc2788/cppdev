//
// same as warmup_1.
//
// changes: -got rid of input switch for moving the character because it did not work (s & d keys worked but not a & w)
//			-added boolean variable to store if a button has been released or not. player can no longer hold down button
//			 to move across the screen with a single button press as done in past sdl projects.
//
#include <cstdlib>
#include <stdio.h>
#include <string>
#include <SDL.h>
#include <SDL_image.h>


int SCREENW = 640;
int SCREENH = 480;

SDL_Window* win1 = NULL;
SDL_Renderer* rend1 = NULL;
SDL_Texture* tex_bgtile = NULL;
SDL_Texture* tex_mchar = NULL;

bool init();
bool loadMedia();
SDL_Texture* loadTexture(std::string img_path);
void close();

int main(int argc, char* argv[]) {
	if (!init())
		printf("init() has failed.\n");
	else
		if (!loadMedia())
			printf("loadMedia() has failed.\n");
		else {
			bool bQuit = false;
			bool bkeyReleased = true;
			SDL_Event event;
			SDL_Rect rTile = { 0, 0, 32, 32 };
			SDL_Rect rPlayer = { 304, 224, 32, 32 };

			while (!bQuit) {
				while (SDL_PollEvent(&event) != 0) {
					if (event.type == SDL_QUIT)
						bQuit = true;

					if (bkeyReleased == true && event.key.keysym.sym == SDLK_w && rPlayer.y > 0) {
						rPlayer.y -= 16;
						bkeyReleased = false;
					}
					else if (bkeyReleased == true && event.key.keysym.sym == SDLK_s && rPlayer.y < 448) {
						rPlayer.y += 16;
						bkeyReleased = false;
					}
					else if (bkeyReleased == true && event.key.keysym.sym == SDLK_a && rPlayer.x > 0) {
						rPlayer.x -= 16;
						bkeyReleased = false;
					}
					else if (bkeyReleased == true && event.key.keysym.sym == SDLK_d && rPlayer.x < 608) {
						rPlayer.x += 16;
						bkeyReleased = false;
					}

					if (event.type == SDL_KEYUP)
						bkeyReleased = true;
					else if (event.type == SDL_KEYDOWN)
						bkeyReleased = false;
				}
				SDL_RenderClear(rend1);
				for (int y = 0; y < 15; y++) {
					for (int x = 0; x < 20; x++) {
						SDL_RenderCopy(rend1, tex_bgtile, NULL, &rTile);
						rTile.x += 32;
					}
					rTile.x = 0;
					rTile.y += 32;
				}
				rTile.x, rTile.y = 0;

				SDL_RenderCopy(rend1, tex_mchar, NULL, &rPlayer);
				SDL_RenderPresent(rend1);
			}
		}

	return 0;
}

bool init() {
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize SDL subsystems. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		win1 = SDL_CreateWindow("sdl warmup 2", SDL_WINDOWPOS_UNDEFINED,
			SDL_WINDOWPOS_UNDEFINED, SCREENW, SCREENH,
			SDL_WINDOW_SHOWN);
		if (win1 == NULL) {
			printf("failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			rend1 = SDL_CreateRenderer(win1, -1, SDL_RENDERER_ACCELERATED);
			if (rend1 == NULL) {
				printf("failed to create renderer. SDL Error: %s\n", SDL_GetError());
				bSuccess = false;
			}
			else {
				SDL_SetRenderDrawColor(rend1, 0xFF, 0xFF, 0xFF, 0xFF);
				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags)) {
					printf("failed to initialize sdl_image. IMG error: %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;
	tex_bgtile = loadTexture("assets/floor32.png");
	if (tex_bgtile == NULL) {
		printf("failed to load texture 'bgtile'.\n");
		bSuccess = false;
	}
	else {
		tex_mchar = loadTexture("assets/npc1.png");
		if (tex_mchar == NULL) {
			printf("failed to load texture 'mchar'.\n");
			bSuccess = false;
		}
	}
	return bSuccess;
}

SDL_Texture* loadTexture(std::string img_path) {
	SDL_Surface* loadSurface = IMG_Load(img_path.c_str());
	if (loadSurface == NULL) {
		printf("failed to load surface. IMG Error: %s\n", IMG_GetError());
	}
	else {
		SDL_Texture* newTexture = SDL_CreateTextureFromSurface(rend1, loadSurface);
		if (newTexture == NULL) {
			printf("failed to create texture from surface. SDL Error: %s\n", SDL_GetError());
		}
		else {
			SDL_FreeSurface(loadSurface);
			loadSurface = NULL;
			return newTexture;
		}
	}
}

void close() {
	SDL_DestroyWindow(win1);
	SDL_DestroyRenderer(rend1);
	SDL_DestroyTexture(tex_bgtile);
	SDL_DestroyTexture(tex_mchar);
	win1 = NULL;
	rend1 = NULL;
	tex_bgtile = NULL;
	tex_mchar = NULL;

	IMG_Quit();
	SDL_Quit();
}