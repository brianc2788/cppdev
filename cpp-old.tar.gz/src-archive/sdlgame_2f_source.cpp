#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* tex_floor32 = NULL;
SDL_Texture* tex_npc4 = NULL;

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize SDL. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		window = SDL_CreateWindow("SDL Game - 2f", SDL_WINDOWPOS_UNDEFINED, \
									SDL_WINDOWPOS_UNDEFINED, nSCREENWIDTH, \
									nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL)
			{
				printf("failed to create renderer. %s\n", SDL_GetError());
				bSuccess = false;
			}
			else
			{
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags))
				{
					printf("failed to initialize SDL_image. %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

SDL_Texture* loadTexture(std::string img_path)
{
	SDL_Texture* newTexture = NULL;
	SDL_Surface* load_surface = IMG_Load(img_path.c_str());
	if (load_surface == NULL)
	{
		printf("failed to load surface from path. %s\n", IMG_GetError());
	}
	else
	{
		newTexture = SDL_CreateTextureFromSurface(renderer, load_surface);
		if (newTexture == NULL)
		{
			printf("failed to create texture from surface. %s\n", SDL_GetError());
		}
		
		SDL_FreeSurface(load_surface);
	}
	return newTexture;
}

bool loadMedia()
{
	bool bSuccess = true;
	tex_floor32 = loadTexture("floor32.png");
	if (tex_floor32 == NULL)
	{
		printf("failed to load floor32.png.\n");
		bSuccess = false;
	}
	
	tex_npc4 = loadTexture("npc4.png");
	if (tex_npc4 == NULL)
	{
		printf("failed to load npc4.png.\n");
	}

	return bSuccess;
}

void close()
{
	SDL_DestroyTexture(tex_floor32);
	tex_floor32 = NULL;

	SDL_DestroyTexture(tex_npc4);
	tex_npc4 = NULL;

	SDL_DestroyRenderer(renderer);
	renderer = NULL;

	SDL_DestroyWindow(window);
	window == NULL;

	IMG_Quit();
	SDL_Quit();
}

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("init() has failed.\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("loadMedia() has failed.\n");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;

			
			SDL_Rect rPlayer = { 304, 224, 32, 32 };

			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.key.keysym.sym == SDLK_UP && rPlayer.y > 0)
						rPlayer.y -= 32;
					else if (event.key.keysym.sym == SDLK_DOWN && rPlayer.y < 448)
						rPlayer.y += 32;
					else if (event.key.keysym.sym == SDLK_LEFT && rPlayer.x > 0)
						rPlayer.x -= 32;
					else if (event.key.keysym.sym == SDLK_RIGHT && rPlayer.x < 608)
						rPlayer.x += 32;
				}
				SDL_RenderClear(renderer);

				SDL_Rect rFloor32 = { 0,0,32,32 };
				for (int y = 0; y <= 15; y++)
				{
					for (int x = 0; x <= 20; x++)
					{
						SDL_RenderCopy(renderer, tex_floor32, NULL, &rFloor32);
						rFloor32.x += 32;
					}
					rFloor32.x = 0;
					rFloor32.y += 32;
				}

				SDL_RenderCopy(renderer, tex_npc4, NULL, &rPlayer);
				SDL_RenderPresent(renderer);
			}
		}
	}
	close();
	return 0;
}