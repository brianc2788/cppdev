//
// stage 1
#include <stdio.h>
#include <cstdlib>
#include <SDL.h>
#include <SDL_image.h>

int SCREENWIDTH = 640;
int SCREENHEIGHT = 480;

bool init();
bool loadMedia();
void close();

SDL_Window* window = NULL;
SDL_Surface* surf_screen = NULL;
SDL_Surface* surf_npc = NULL;

int main(int argc, char* argv[]) {
	if (!init()) {
		printf("init() failed.\n");
	}
	else {
		if (!loadMedia()) {
			printf("loadMedia() failed.\n");
		}
		else {
			// apply image.
			SDL_BlitSurface(surf_npc, NULL, surf_screen, NULL);
			// update screen.
			SDL_UpdateWindowSurface(window);

			SDL_Delay(3000);
		}
	}

	close();

	return 0;
}

bool init() {
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("failed to initialize. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("sdl test1", SDL_WINDOWPOS_UNDEFINED, \
			SDL_WINDOWPOS_UNDEFINED, SCREENWIDTH, \
			SCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %n", SDL_GetError());
			bSuccess = false;
		}
		else {
			surf_screen = SDL_GetWindowSurface(window);
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;
	// load splash image
	surf_npc = SDL_LoadBMP("assets/npc0.bmp");
	if (surf_npc == NULL) {
		printf("failed to load bmp. %s\n", SDL_GetError());
		bSuccess = false;
	}
	return bSuccess;
}

void close() {
	SDL_FreeSurface(surf_npc);
	surf_npc = NULL;
	SDL_DestroyWindow(window);
	window = NULL;
	SDL_Quit();
}