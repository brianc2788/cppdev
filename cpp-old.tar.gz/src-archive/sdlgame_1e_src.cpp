/*******************************************************************************
	sdl game - 1e
	build 08022018

	rewrite up to image optimization.
*******************************************************************************/
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* window = NULL;
SDL_Surface* screen = NULL;
SDL_Surface* sFace_mChar = NULL;

bool init();
bool loadMedia();
void close();
SDL_Surface* loadSurface(std::string img_path);

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("init() has failed\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("loadMedia() has failed.\n");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;
			int nPlayerPosX = 304;
			int nPlayerPosY = 224;
			SDL_Rect rPlayer = { nPlayerPosX, nPlayerPosY, NULL, NULL };

			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.key.keysym.sym == SDLK_UP && nPlayerPosY > 0)
						nPlayerPosY -= 5;
					else if (event.key.keysym.sym == SDLK_DOWN && nPlayerPosY < 448)
						nPlayerPosY += 5;
					else if (event.key.keysym.sym == SDLK_LEFT && nPlayerPosX > 0)
						nPlayerPosX -= 5;
					else if (event.key.keysym.sym == SDLK_RIGHT && nPlayerPosX < 608)
						nPlayerPosX += 5;
				}

				rPlayer = { nPlayerPosX, nPlayerPosY, NULL, NULL };
				SDL_BlitSurface(sFace_mChar, NULL, screen, &rPlayer);
				SDL_UpdateWindowSurface(window);
			}
		}
	}

	close();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize SDL video. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		window = SDL_CreateWindow("sdl game - 1e", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, \
									nSCREENWIDTH, nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			int imgFlags = IMG_INIT_PNG;
			if (!IMG_Init(imgFlags) & imgFlags)
			{
				printf("failed to initialize SDL_image. %s\n", IMG_GetError());
				bSuccess = false;
			}
			
			screen = SDL_GetWindowSurface(window);
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	sFace_mChar = loadSurface("NPC2.png");
	if (sFace_mChar == NULL)
	{
		printf("error\n");
		bSuccess = false;
	}
	return bSuccess;
}

void close()
{
	SDL_DestroyWindow(window);
	window = NULL;

	SDL_FreeSurface(screen);
	screen = NULL;

	SDL_FreeSurface(sFace_mChar);
	sFace_mChar = NULL;

	IMG_Quit();
	SDL_Quit();
}

SDL_Surface* loadSurface(std::string img_path)
{
	SDL_Surface* opt_image = NULL;
	SDL_Surface* load_image = IMG_Load(img_path.c_str());
	if (load_image == NULL)
	{
		printf("failed to load image at path. %s\n", IMG_GetError());
	}
	else
	{
		opt_image = SDL_ConvertSurface(load_image, screen->format, NULL);
		if (opt_image == NULL)
		{
			printf("failed to optimize image. %s\n", IMG_GetError());
		}

		SDL_FreeSurface(load_image);
	}
	return opt_image;
}