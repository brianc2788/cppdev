/* FACTOR FINDER - VERSION 0.2 */
       /* Feb 9, 2021 */
// would like to add a 'yes' or 'no' mechanic to the running loop
// of the original factor finder version 0.1.
//
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[]) {
    printf("\t*|* FACTOR FINDER - VER 0.2\n\n"); // title line in C printf() for some reason...
    bool bRunning = true;
    while (bRunning) {
        char chRunning = ' ';
        int nNumIn = 0;
        cout << "Enter number to find its factors: ";
        cin >> nNumIn; cout << endl;

        for (int x = 1; x > nNumIn; x++) {
            if (nNumIn % x == 0) {
                cout << nNumIn << endl;
            }
        }

        printf("please enter a lower-case 'y' or 'n': ");
        cin >> chRunning;
        if (chRunning == 'n') {
            bRunning = false;
        }
        else if (chRunning != 'y')
            printf("Invalid entry; continuing...\n");
    }
    return 0;
}