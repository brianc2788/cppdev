/******************************************************************************
	Project Euler - Problem 10

	From: https://projecteuler.net/problem=10
	"The sum of the primes below 10 is 2 + 3 + 5 + 7 = 17.
	Find the sum of all the primes below two million."

******************************************************************************/
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[])
{
	unsigned int nSum = 0;
	unsigned int nArray[] = { NULL };

	nArray[0] = 1;
	nArray[1] = 44;

	for (int x = 0; x < nArray.length(); x++)
	{
		if()
	}

	getchar();
	return 0;
}