/*

	CTIMER - Version 3.0 release
	Build 04092018

	updating for better appearance and user-friendlyness using
	better coding techniques; especially for getting input.

*/
#include <iostream>
#include <conio.h>
#include <ctime>
using namespace std;

char getKey();
char getKey_noBlock();

int main(int argc, char* argv[]) {

	cout << "CTIMER - v3.0" << endl << endl;

	bool bRunning = true;
	bool bTiming = false;

	while (bRunning) {

		cout << "press enter to start the timer. . ." << endl
			<< "then press the spacebar to stop" << endl << endl;

		if (getKey() == '\r') {
			clock_t ctStart = clock();
			bTiming = true;
			while (bTiming) {
				clock_t ctCurrent = clock();
				cout << (double)(ctCurrent - ctStart) / CLOCKS_PER_SEC << endl;
				cin.ignore();
				char c = _getch();

				if (c == ' ')
					bTiming = false;
			}
		}

	}

	return 0;
}

char getKey() {
	char cKey;
	bool bKeyPressed = false;

	while (!bKeyPressed) {

		cKey = _getch();

		if (cKey == ' ')
			return ' ';
		else if (cKey == '\r')
			return '\r';
	}

}

char getKey_noBlock() {
	char cKey = _getch();

	if (cKey == ' ')
		return ' ';
	else
		return NULL;
}