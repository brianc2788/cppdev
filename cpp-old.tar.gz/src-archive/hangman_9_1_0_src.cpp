/*

	Hangman - v9.1.0
	Build 04292018

	perfecting writing to a screen buffer.

*/
#include "hman_util.h"

int main(int argc, char* argv[]) {

	return EXIT_SUCCESS;
}