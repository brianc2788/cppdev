//
// quick sdl app
//
// npc image is not loading/optimizing/blitting correctly. shows a black square in its place.
#include <stdio.h>
#include <cstdlib>
#include <SDL.h>
#include <SDL_image.h>
#include <string>

int SCREENWIDTH = 640;
int SCREENHEIGHT = 480;
SDL_Window* window = NULL;
SDL_Surface* surf_screen = NULL;
SDL_Surface* surf_floor = NULL;
SDL_Surface* surf_npc = NULL;

bool init();
SDL_Surface* loadSurface(std::string path);
bool loadMedia();
void close();

int main(int argc, char* argv[]) {
	if (!init()) {
		printf("init() has failed.\n");
	}
	else {
		if (!loadMedia()) {
			printf("loadMedia() has failed.\n");
		}
		else {
			bool bQuit = false;
			SDL_Event event;
			SDL_Rect rFloor = { 0,0,32,32 };
			SDL_Rect rNpc = { 302,224,32,32 };

			while (!bQuit) {
				while (SDL_PollEvent(&event) != 0) {
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.key.keysym.sym == SDLK_w && rNpc.y > 0)
						rNpc.y -= 5;
					else if (event.key.keysym.sym == SDLK_s && rNpc.y < 448)
						rNpc.y += 5;
					else if (event.key.keysym.sym == SDLK_a && rNpc.x > 0)
						rNpc.x -= 5;
					else if (event.key.keysym.sym == SDLK_d && rNpc.x < 608)
						rNpc.x += 5;
				}

				rFloor.x = 0; rFloor.y = 0;
				for (int y = 0; y < 15; y++) {
					for (int x = 0; x < 20; x++) {
						SDL_BlitSurface(surf_floor, NULL, surf_screen, &rFloor);
						rFloor.x += 32;
					}
					rFloor.x = 0;
					rFloor.y += 32;
				}

				SDL_BlitSurface(surf_npc, NULL, surf_screen, &rNpc);
				SDL_UpdateWindowSurface(window);
			}
		}
	}

	close();
	return 0;
}

bool init() {
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize SDL. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("quick sdl", SDL_WINDOWPOS_UNDEFINED, \
			SDL_WINDOWPOS_UNDEFINED, SCREENWIDTH, \
			SCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			int imgFlags = IMG_INIT_PNG;
			if (!(IMG_Init(imgFlags) & imgFlags)) {
				printf("failed to initialize sdl_image. %s\n", IMG_GetError());
				bSuccess = false;
			}
			else {
				surf_screen = SDL_GetWindowSurface(window);
			}
		}
	}
	return bSuccess;
}

SDL_Surface* loadSurface(std::string path) {
	SDL_Surface* opt_image = NULL; // optimized image
	SDL_Surface* load_image = NULL; // image to be loaded
	load_image = IMG_Load(path.c_str());
	if (load_image == NULL) {
		printf("%s\n", IMG_GetError());
	}
	else {
		opt_image = SDL_ConvertSurface(load_image, surf_screen->format, NULL);
		if (opt_image == NULL) {
			printf("%s\n", IMG_GetError());
		}
	}
	SDL_FreeSurface(load_image);
	return opt_image;
}

bool loadMedia() {
	bool bSuccess = true;
	surf_floor = loadSurface("assets/floor32.png");
	if (surf_floor == NULL) {
		printf("failed to load png.\n");
		bSuccess = false;
	}
	else {
		surf_npc = loadSurface("assets/npc0.png");
		if (surf_npc == NULL) {
			printf("failed to load png.\n");
			bSuccess = false;
		}
	}
	return bSuccess;
}

void close() {
	SDL_DestroyWindow(window);
	window = NULL;
	SDL_FreeSurface(surf_floor);
	surf_floor = NULL;
	SDL_FreeSurface(surf_npc);
	surf_npc = NULL;
	SDL_Quit();
}
                                                                                                                                                                      