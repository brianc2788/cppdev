/*

	LOTTERY MANAGER
	Written for KK Food Mart - 3xxx Southwestern Blvd.
							   Orchard Park, NY 14127
							   (716) -

	great practice with filestreams and getline, if nothing else.

	created:	2 19 18
	updates:	2-20-18		- complete design overhaul.
							creates a new file for each
							ticket.
							- another all-nighter.
							so worth it. made a brilliant
							discovery that will make this
							much easier and marks a leap
							forward in my programming
							knowledge. level up.
				2-19-18		- general tweaks.
				2-19-18		- on the way to full functionality.
							using custom textfile format,
							can write new lotto ticket entries
							into the file and read each one back
							with a name, book number, and price.
							how to get specific information
							out of a file and perform 
							calculations on it...
							Then how to do calculations
							on all of the information in
							the file.
	// ADD - record dates and money earned. file directories??
*/

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <Windows.h> // for output handle
using namespace std;

void updateTicket();
void calcSaleSingle();
double calcSaleSingle1();
void calcSaleSeries();

int main(int nNumberofArgs, char * pszArgs[]) {
	// TITLE
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 26);
	cout << endl
		<< "\t[X][X][X][X] LOTTO MANAGER [X][X][X][X]"
		<< endl;
	SetConsoleTextAttribute(hConsole, 7);
	bool running = true;
	while (running) {
		// MAIN MENU
		SetConsoleTextAttribute(hConsole, 26);
		cout << "\n[X][X] MAIN MENU [X][X]";
		SetConsoleTextAttribute(hConsole, 7);
		cout << endl << endl;
		cout << "Select option number:" << endl << endl
			<< "1 - Calculate a sale" << endl
			<< "2 - Enter todays sales" << endl
			<< "3 - Update a ticket" << endl
			<< "0 - Quit" << endl;
	TryAgain:
		cout << "Enter: ";
		int mainMenu;
		cin >> mainMenu; cout << endl;

		switch (mainMenu) {
		case 1:
			calcSaleSingle();
			break;
		case 2:
			calcSaleSeries();
			break;
		case 3:
			updateTicket();
			break;
		case 0:
			running = false;
			break;
		default:
			cout << "Invalid option" << endl;
			goto TryAgain;
		}
	}

	return 0;
}

void updateTicket() {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 26);
	cout << "[X][X] UPDATE TICKET [X][X]";
	SetConsoleTextAttribute(hConsole, 7);
	string newName;
	string bookNum;
	double tickPrice;
	cout << endl << endl;
	cout << "Enter ticket information: " << endl
		<< "Name: ";	
	cin.ignore();
	getline(cin, newName);
	cout << endl << "Book #: ";
	getline(cin, bookNum);
	cout << endl << "Price: ";
	cin >> tickPrice; cout << endl;

	string newFileName = newName;
	newFileName.append(".txt");
	ofstream newFile;
	newFile.open(newFileName.c_str());

	while (newFile) {

		newFile << newName << endl << bookNum << endl << tickPrice << endl;
		newFile.close();
	}

	cout << "Ticket Updated. Returning to Menu." << endl;
	system("PAUSE");
}

void calcSaleSingle() {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 26);
	cout << "[X][X] CALCULATE SALE [X][X]" << endl << endl;
	SetConsoleTextAttribute(hConsole, 7);
	cout << "Enter ticket name: ";
	string searchName;
	cin.ignore();
	getline(cin, searchName);
	
	searchName.append(".txt");
	ifstream searchFile;
	searchFile.open(searchName.c_str(), ifstream::beg);



	string tickName = "";
	string bookNum;
	double tickPrice;

	while (searchFile) { // this while loop is extremely delicate...
		getline(searchFile, tickName);
		getline(searchFile, bookNum);
		searchFile >> tickPrice;
		searchFile.close();
		searchFile.ignore();
	}

	if (tickName == "") {
		cout << "No results. Returning to main menu ." << endl;
		goto Exit;
	}

	SetConsoleTextAttribute(hConsole, 2);
	cout << endl << tickName << endl << "Book No.: " << bookNum << endl << "Price: $" << tickPrice << endl << endl;
	SetConsoleTextAttribute(hConsole, 7);

	int startNum;
	int endNum;
	cout << "Enter START #: "; cin >> startNum; cout << endl;
	cout << "Enter END #: "; cin >> endNum; cout << endl << endl;

	cout << bookNum << " " << tickName << ":\t Sold " << (endNum - startNum) << " tickets for $" << (tickPrice * (double)(endNum - startNum)) << endl;

	Exit:

	system("PAUSE");
}

double calcSaleSingle1() {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	cout << "Enter ticket name: ";
	string searchName;
	cin.ignore();
	getline(cin, searchName);

	searchName.append(".txt");
	ifstream searchFile;
	searchFile.open(searchName.c_str(), ifstream::beg);



	string tickName = "";
	string bookNum;
	double tickPrice;

	while (searchFile) {
		getline(searchFile, tickName);
		getline(searchFile, bookNum);
		searchFile >> tickPrice;
		searchFile.close();
		searchFile.ignore();
	}

	if (tickName == "") {
		cout << "No results." << endl;
		cin.ignore();
		goto Exit;
	}

	SetConsoleTextAttribute(hConsole, 4);
	cout << endl << tickName << endl << "Book No.: " << bookNum << endl << "Price: $" << tickPrice << endl << endl;
	SetConsoleTextAttribute(hConsole, 7);
	int startNum;
	int endNum;
	cout << "Enter START #: "; cin >> startNum; cout << endl;
	cout << "Enter END #: "; cin >> endNum; cout << endl << endl;
	SetConsoleTextAttribute(hConsole, 10);
	cout << bookNum << " " << tickName << ":\t Sold " << (endNum - startNum) << " tickets for $" << (tickPrice * (double)(endNum - startNum)) << endl;
	

Exit:

	return (tickPrice * (double)(endNum - startNum));
}

// do sheet of lottery tickets
void calcSaleSeries() {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 26);
	cout << "[X][X] STARTING SERIES... [X][X]" << endl << endl;
	SetConsoleTextAttribute(hConsole, 7);
	bool running = true;
	double totalSale = 0;

	while (running) {
		
		totalSale = (totalSale + calcSaleSingle1());
		SetConsoleTextAttribute(hConsole, 26);
		cout << "\n[X][X] TOTAL SALE: $" << totalSale << " [X][X]" << endl << endl;
		SetConsoleTextAttribute(hConsole, 7);
		int repeatOption;

		AskAgain:
		cout << "Enter another ticket?\n1 - YES\t\t2 - NO\nEnter 1 or 2: ";

		cin >> repeatOption; cout << endl;

		if (repeatOption == 1) {
			running = true;
		}
		else if (repeatOption == 2) {
			running = false;
		}
		else {
			cout << "Invalid" << endl;
			cin.ignore();
			goto AskAgain;
		}

	}
}


///////////////////////////////////////////////////////////
//// ALL THE OLD CRAP THAT DIDNT WORK..............////////
//////////////////////////////////////////////////////////
//a monument of my [programming] sins.......

//// ADD NEW TICKET TO DATABASE (lotterytickets.txt)
//void addTick() {
//	ofstream lotterytickets("lotterytickets.txt", ofstream::app);
//
//	char name[20];
//	string bookNo;
//	double price;
//
//	cout << "\n[X][X] ADD TICKET [X][X]" << endl
//		<< "Name: ";
//	cin.ignore();
//	cin.getline(name, sizeof(name)); cout << endl;
//	//cin.ignore();
//	//getline(cin, name); cout << endl;
//	cout << "Book #: ";
//	cin >> bookNo; cout << endl;
//	cout << "Price: ";
//	cin >> price; cout << endl;
//	lotterytickets << name << endl << bookNo << endl << price << endl;
//	
//	lotterytickets.close();
//
//	cout << "Saved new ticket." << endl;
//	system("PAUSE");
//}
//
//// DRAW FROM DATABASE (lotterytickets.txt), SET NEW VARS AND PERFORM CALCULATIONS
//void calcSale() {
//	ifstream lotterytickets("lotterytickets.txt", ifstream::in);
//
//	int tickNum = 1;
//	string name;
//	string bookNum;
//	double price;
//
//	// display saved tickets
//	cout << "Ticket Number:" << endl;
//	while (lotterytickets) {
//		getline(lotterytickets, name);
//
//		// needed because program would not stop outputting after the last lottery ticket. probably due to there is a new line at the end of the file.
//		if (name == "") {
//			break;
//		}
//		else {  }
//
//		lotterytickets >> bookNum >> price;
//		cout << tickNum << " --------- " << name << " " << bookNum << " $" << price << endl;
//		tickNum++;
//		lotterytickets.ignore();
//	}
//
//	calcSalePart2();
//	
//
//
//	system("PAUSE");
//}
//
//void calcSalePart2() {
//	ifstream lotterytickets("lotterytickets.txt", ifstream::in);
//	// select ticket to perform calculation
//	int selTick;
//	cout << "\nEnter Ticket Number: ";
//	cin >> selTick; cout << endl;
//	// my method for re-opening the file and putting the file pointer where i want... cant figure out seekp/g so using getline..
//	lotterytickets.open("lotterytickets.txt", ifstream::in);
//	string tickBuff;
//	string newname;
//	string newBookNum;
//	double newprice;
//	while (lotterytickets) {
//	for (int x = 1; x < ((selTick * 3) - 2); x++) {
//		getline(lotterytickets, tickBuff);
//	}
//
//	getline(lotterytickets, newname);
//	lotterytickets >> newBookNum >> newprice;
//	lotterytickets.close();
//	}
//
//	int startNum;
//	int endNum;
//	cout << "Enter START: ";
//	cin >> startNum; cout << endl;
//	cout << "Enter END: ";
//	cin >> endNum; cout << endl << endl;
//
//	cout << newname << " " << newBookNum << ": Sold " << (endNum - startNum) << " tickets for "
//		<< (newprice * (endNum - startNum)) << endl;
//}