/*****************************************************************************/

// KK Food Mart - Lottery Manager
//
// Written for:
// KK Food Mart - 3846 Southwestern Blvd
//				  Orchard Park, NY 14127
//				  Phone: (716) 312-0771
//
// Developer: Brian Chiodo
// created: 2/17/18
// last update: 2/17/18

/*****************************************************************************/
#include <iostream>
#include <string>
using namespace std;

int main(int nNumberofArgs, char * pszArgs[]) {
	// title
	cout << "_________________________________________" << endl
		<< "\n[X][X][X][X] LOTTERY MANAGER [X][X][X][X]\t\tbrianc, Copyright 2018" << endl
		<< "_________________________________________" << endl;

	bool Quit = false;
	while (!Quit) {
		cout << "\n\n\t[X][X] MAIN MENU [X][X]" << endl;


	TryAgain:
		cout << "\nEnter: ";
		int menuOption;
		cin >> menuOption; cin.ignore(); cout << endl;

		if (menuOption == 1) {
			cout << "option 1" << endl;
			continue;
		}
		else if (menuOption == 2) {
			cout << "option 2" << endl;
		}
		else if (menuOption == 3){
			cout << "quitting..." << endl;
			Quit = true;
			return Quit;
		}
		else{
			cout << "Invalid entry. Press 1, 2, 3 and ENTER only!" << endl;
			goto TryAgain;
		}
		cout << "end. restarting..." << endl;
	}
	cout << "post loop" << endl;
		
	system("PAUSE");
	return 0;
}


//// use enum for variables you will eventually get (eg when loading the file with lottery ticket)
//enum something {
//	thing1,
//	thing2,
//	thing3,
//	thing4
//};

class scratchOffs
{
public:
	scratchOffs() {
	}
	~scratchOffs() {
	}
public:
	void function() {
	}
	auto variable() {
	}
private:
	int var1;
};





//// not sure how to practically apply to the QP lottery ticks and such.
//class lotteryTickets
//{
//public:
//	lotteryTickets() {
//	}
//	~lotteryTickets() {
//	}
//public:
//	void function();
//};
////*****how to define outside of class in the same file*****/
//void lotteryTickets::function()
//{
//	// nothing yet
//}