/*
	setting up SDL with VC++....
*/
#include <SDL.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	SDL_Init(SDL_INIT_EVERYTHING);

	SDL_Delay(5000);

	SDL_Quit();

	return 0;
}


/******************************************************************************
				DIRECTIONS FOR SETTING UP SDL WITH VC++
******************************************************************************/
/*
PROJECT / PROPERTIES / VC++ DIRECTORIES
-Add SDL include folder to INCLUDE DIRECTORIES
-Add SDL lib folder to LIBRARY DIRECTORIES

PROJECT / PROPERTIES / LINKER / INPUT
-Additional Dependancies: -SDL2.lib, -SDL2main.lib

PROJECT / PROPERTIES / LINKER / SYSTEM
-Set SUBSYSTEM to either Console or Windows.

*/