//
// documenting the evolution of the sdl tutorial from http://lazyfoo.net
#include <stdio.h>
#include <cstdlib>
#include <SDL.h>
#include <SDL_image.h>

int SCREENWIDTH = 640;
int SCREENHEIGHT = 480;

int main(int argc, char* argv[]) {
	SDL_Window* window = NULL;
	SDL_Surface* surf1 = NULL;

	// initialize SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("failed to initialize SDL. %s\n", SDL_GetError());
	}
	else {
		window = SDL_CreateWindow("sdl test", SDL_WINDOWPOS_UNDEFINED, \
			SDL_WINDOWPOS_UNDEFINED, SCREENWIDTH, \
			SCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %s\n", SDL_GetError());
		}
		else {
			// get window surface.
			surf1 = SDL_GetWindowSurface(window);
			// fill white
			SDL_FillRect(surf1, NULL, SDL_MapRGB(surf1->format, 0xFF, 0xFF, 0xFF));
			// update surface.
			SDL_UpdateWindowSurface(window);

			SDL_Delay(3000);
		}
	}

	// destroy window and quit subsystems.
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}