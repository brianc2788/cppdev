/* Have Fun! */

#include <iostream>
#include <ctime>
#include <Windows.h>

	int nScreenWidth = 40;
	int nScreenHeight = 40;

	int main(int argc, char* argv[]) {
		puts("hi");
		wchar_t* pScreen = new wchar_t[nScreenWidth * nScreenHeight];
		for (int i = 0; i < nScreenWidth * nScreenHeight; i++) { pScreen[i] = L' '; }
		HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
		DWORD dwBytesWritten = 0;

		SetConsoleTitle("CTIMER 4.5");
		SetConsoleTextAttribute(hConsole, 0x0070);
		SetConsoleScreenBufferSize(hConsole, { 40, 40 });
		SetConsoleActiveScreenBuffer(hConsole);

		swprintf_s(&pScreen[0], 11, L"CTIMER 4.5");
		WriteConsole(hConsole, pScreen, nScreenWidth * nScreenHeight, &dwBytesWritten, NULL);

		bool bRunning = true;
		bool bTiming = false;

		while (bRunning) {

			swprintf_s(&pScreen[40], 16, L"W - start timer");
			swprintf_s(&pScreen[80], 15, L"E - stop timer");
			swprintf_s(&pScreen[120], 9, L"Q - quit");
			WriteConsole(hConsole, pScreen, nScreenWidth * nScreenHeight, &dwBytesWritten, NULL);

			if (GetAsyncKeyState((unsigned char)'W')) {
				bTiming = true;
				clock_t ctStart, ctCurrent;
				ctStart = clock();

				while (bTiming) {
					ctCurrent = clock();

					swprintf_s(&pScreen[200], 13, L"SEC ELAPSED:");
					swprintf_s(&pScreen[240], 11, L"%f", ((float)(ctCurrent - ctStart) / CLOCKS_PER_SEC));

					WriteConsole(hConsole, pScreen, nScreenWidth * nScreenHeight, &dwBytesWritten, NULL);

					if (GetAsyncKeyState((unsigned char)'E'))
						bTiming = false;

				}
			}
			else if (GetAsyncKeyState((unsigned char)'Q'))
				bRunning = false;
		}

		CloseHandle(hConsole);
		return 0;
	}
	}