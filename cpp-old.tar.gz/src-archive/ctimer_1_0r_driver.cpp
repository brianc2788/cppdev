/*

	CTIMER
	Version:	1.0 release
	Build:		04072018

	this version:
	added a loop so user can see current seconds elapsed until they want to stop.
	added separate header file containing a timer class - jff.

	final:	scrapped the separate header file due to overcomplicity.
			user-friendly. follow on screen prompts.

*/
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

#include <iostream>
#include <ctime>
#include <string>
using namespace std;

int main() {

	cout << "CTIMER - v1.0r\nBuild 04072018" << endl << endl;

	string sCmd;
	bool bRunning = true;

	while (bRunning) {

		cout << "ENTER 'start' or 'quit': ";
		cin >> sCmd; cout << endl << endl;

		if (sCmd == "start") {

			clock_t ctStart = clock();

			bool bTimerStop = false;
			while (!bTimerStop && sCmd != "quit") {

				clock_t ctCurrent;

				cout << "'go' to view sec elapsed and keep going or 'stop': ";
				cin >> sCmd; cout << endl;

				if (sCmd == "stop") {
					ctCurrent = clock();
					cout << "TIMER STOPPED\nseconds elapsed: " << (double)(ctCurrent - ctStart) / CLOCKS_PER_SEC << endl << endl;
					bTimerStop = true;
				}
				else if (sCmd == "go") {
					ctCurrent = clock();
					cout << "CURRENT\nseconds elapsed: " << (double)(ctCurrent - ctStart) / CLOCKS_PER_SEC << endl;
				}
				
			}

		}

		else if (sCmd == "quit")
			bRunning = false;

	}

	return EXIT_SUCCESS;
}