/*******************************************************************************
	Project Euler - 22 (ver c)

	Problem (from http://projecteuler.net):
	Using names.txt (right click and 'Save Link/Target As...'), a 46K text file
	containing over five-thousand first names, begin by sorting it into
	alphabetical order. Then working out the alphabetical value for each name,
	multiply this value by its alphabetical position in the list to obtain a
	name score.
	
	For example, when the list is sorted into alphabetical order,
	COLIN, which is worth 3 + 15 + 12 + 9 + 14 = 53,
	is the 938th name in the list.
	So, COLIN would obtain a score of 938 � 53 = 49714.
	
	What is the total of all the name scores in the file?

	- user must enter a file name because why not. just for fun.
	- big part of the challenge here is the whack ass format of the file.
	  time to master the input strean and things like delimiters.
	  actually, ifile.ignore() might do the trick.
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

int main(int argc, char* argv[]) {
	ifstream fileIn;
	string fileName;
	vector<string> listNames[5500];
	char nextChar;
	string theFile;

	printf("Project Euler - Problem 22 (ver C)\n\n");

	cout << "Enter file name: ";
	cin >> fileName; cout << endl;

	fileIn.open(fileName.c_str(), ifstream::in);
	if (!fileIn.is_open()) {
		printf("File %s not found.\nPress ENTER to exit.\n", fileName.c_str());
		cin.ignore();
		getchar();
		return 0;
	}

	fileIn.delim('\"');
	fileIn[1] >> nextChar;
	printf("%s\n", nextChar);

	printf("File %s successfully opened.\nClosing file.\nPress ENTER to exit.\n", fileName.c_str());
	fileIn.close();
	cin.ignore();
	getchar();

	return 0;
}