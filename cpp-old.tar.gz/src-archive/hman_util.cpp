#include "hman_util.h"

UTILITY::UTILITY() {
}

UTILITY::~UTILITY() {
}