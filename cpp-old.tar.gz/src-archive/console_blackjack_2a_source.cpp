/*******************************************************************************
	Console Blackjack - ver 2a
	build 08182018

	multiple classes, enumerations, and data structs.
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <string>
#include "con_blackjack.h"
using namespace std;

struct CARD {
	int nDeckNo;
	int nValue = getCardValue(nDeckNo);
	string sName;
};

int getCardValue(int nDeckNo);
void GameOn();

int main(int argc, char* argv[])
{
	printf("BlackJack - v.2a\t****\n\n");

	bool bQuit = false;
	while (!bQuit)
	{
		int nOption;
		printf("1 - Deal Cards\t2 - Quit\nEnter: ");
		cin >> nOption; cout << endl << endl;

		if (nOption == 1)
			GameOn();
		else if (nOption == 2)
			bQuit = true;
		else
			printf("Invalid entry...\n\n");
	}

	getchar();
	return 0;
}

void GameOn()
{
	CON_BLACKJACK BJACK;
	CON_BLACKJACK::CARD computer[10];
	CON_BLACKJACK::CARD user[10];

	// constructor has dealt 2 cards each, update CARD arrays for each player.
}

int getCardValue(int nDeckNo)
{

}