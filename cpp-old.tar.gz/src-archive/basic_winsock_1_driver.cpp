/*******************************************************************************
	basic winsoc app - build 08012018
*******************************************************************************/
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")

int main(int argc, char* argv[])
{
	WSADATA wsaData;

	int iResult;
	// init winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0)
	{
		printf("WSAStartup has failed. %d\n", iResult);
		getchar();
		return 1;
	}

	return 0;
}