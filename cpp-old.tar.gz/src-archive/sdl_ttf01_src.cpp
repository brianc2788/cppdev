///*******************************************************************************
//	SDL TTF test 01
//*******************************************************************************/
//#include <stdio.h>
//#include <string>
//#include <cmath>
////#define SDL_MAIN_HANDLED
//// used in codeblocks to avoid undefined reference error for WinMain@16...
//#include <SDL.h>
//#include <SDL_image.h>
//#include <SDL_ttf.h>
//
//// global variables.
//SDL_Window* window = NULL;
//SDL_Renderer* renderer = NULL;
//SDL_Texture* texture = NULL;
//TTF_Font* font = NULL;
//
//int main(int argc, char* argv[]) {
//	
//	SDL_Init(SDL_INIT_VIDEO);
//	IMG_Init(IMG_INIT_PNG);
//	TTF_Init();
//
//	window = SDL_CreateWindow("sdl ttf test 01", SDL_WINDOWPOS_UNDEFINED, \
//		SDL_WINDOWPOS_UNDEFINED, 640, 480, SDL_WINDOW_SHOWN);
//
//	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
//
//	SDL_Delay(3000);
//	// CLOSING
//	SDL_DestroyWindow(window);
//	window = NULL;
//	SDL_DestroyTexture(texture);
//	texture = NULL;
//	SDL_DestroyRenderer(renderer);
//
//	TTF_CloseFont(font);
//	font = NULL;
//
//	SDL_Quit();
//	IMG_Quit();
//	TTF_Quit();
//
//	return 0;
//}


//
// better
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <stdio.h>
#include <string>
#include <cmath>

int SCREEN_WIDTH = 640;
int SCREEN_HEIGHT = 480;

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* tex_text = NULL;


bool init();

int main(int argc, char* argv[]) {



	return 0;
}

bool init() {
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("SDL failed to initialize. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("sdl ttf test", SDL_WINDOWPOS_UNDEFINED, \
								  SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, \
								  SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
	}

	return bSuccess;
}

