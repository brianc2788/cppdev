/******************************************************************************
	Project Euler - Problem 09

	From: https://projecteuler.net/problem=9
	"A Pythagorean triplet is a set of three natural numbers, a < b < c, for which,
	a2 + b2 = c2
	For example, 3^2 + 4^2 = 9 + 16 = 25 = 5^2.
	There exists exactly one Pythagorean triplet for which a + b + c = 1000.
	Find the product abc."

	This has to be a typo because there is no set of three, consecutive
	numbers that equal 1000. The closest that can be gotten is:

	332+333+334 = 999

	They want a^2 + b^2 + c^2 = 1000 ?

	update - doesnt say they have to be consecutive...
******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <ctime>
using namespace std;

int main(int argc, char* argv[])
{
	unsigned int nA = 1;
	unsigned int nB = 2;
	unsigned int nC = 3;

	bool b1000 = false;

	while (!b1000)
	{
		if (((nA*nA) + (nB*nB) + (nC*nC)) == 1000)
		{
			cout << "A: " << nA << "\tB: " << nB << "\tC: " << nC << endl
				 << "Sum: 1000" << endl;
			printf("Product: %lld\n", (nA*nB*nC));
			b1000 = true;
		}
		else
		{
			nA++;
			nB++;
			nC++;
			continue;
		}
	}

	getchar();
	return 0;
}

//int main(int argc, char* argv[])
//{
//	cout << "Project Euler - Problem 09" << endl << endl
//		 << "From https://projecteuler.net/problem=9\n" << endl
//		 << "'...There exists exactly one Pythagorean triplet for which a + b + c = 1000." << endl
//		 <<	"Find the product abc.'" << endl << endl;
//
//	int nA = 1;
//	int nB = 2;
//	int nC = 3;
//	bool bPythTriplet = false;
//
//	while (!bPythTriplet)
//	{
//		if (nA + nB + nC == 1000 && nA < nB && nB < nC)
//		{
//			cout << "A: " << nA << endl
//				 << "B: " << nB << endl
//				 << "C: " << nC << endl << endl
//				 << "Product: " << (nA*nB*nC) << endl << endl;
//			bPythTriplet = true;
//		}
//		else
//		{
//			nA = srand(time(NULL));
//		}
//	}
//
//	printf("Press any key to exit...");
//
//	getchar();
//	return 0;
//}