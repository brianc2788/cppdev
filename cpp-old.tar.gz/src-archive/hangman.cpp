#include "hangman.h"

hmUtil::hmUtil() {
	Hword hw;
	hw.word = "hwstring";
}
hmUtil::~hmUtil() {

}
