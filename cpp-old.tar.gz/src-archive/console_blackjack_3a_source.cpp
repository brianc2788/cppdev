/*******************************************************************************
	Console Blackjack - ver 3a
	build 08182018

	in progress...
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <string>
#include <ctime>

class blackjack
{
public:
	// called by main
	void BJGameOn()
	{
		
	}

	struct card
	{
		int nValue;
		std::string sName;
	} cards_cpu[10], cards_player[10];

private:
	int nCPUTurn = 1, nPlayerTurn = 1;
	CARD_DECK cd;	
};

class CARD_DECK : public blackjack {
public:
	void DrawCard(card hand[10], int turn) {
		int newCard = ((rand() % 52) + 1);
		while (bCardDeck[newCard])
		{
			newCard = ((rand() % 52) + 1);
		}
		bCardDeck[newCard] = false;
		
		if (newCard == TWO_HEARTS) {
			hand[turn].nValue = 2;
			hand[turn].sName = "2H";
		}
		else if (newCard == THREE_HEARTS) {
			hand[turn].nValue = 3;
			hand[turn].sName = "3H";
		}
		else if (newCard == FOUR_HEARTS) {
			hand[turn].nValue = 4;
			hand[turn].sName = "4H";
		}
		else if (newCard == FIVE_HEARTS) {
			hand[turn].nValue = 5;
			hand[turn].sName = "5H";
		}
		else if (newCard == SIX_HEARTS) {
			hand[turn].nValue = 6;
			hand[turn].sName = "6H";
		}
		else if (newCard == SEVEN_HEARTS) {
			hand[turn].nValue = 7;
			hand[turn].sName = "7H";
		}
		else if (newCard == EIGHT_HEARTS) {
			hand[turn].nValue = 8;
			hand[turn].sName = "8H";
		}
		else if (newCard == NINE_HEARTS) {
			hand[turn].nValue = 9;
			hand[turn].sName = "9H";
		}
		else if (newCard == TEN_HEARTS) {
			hand[turn].nValue = 10;
			hand[turn].sName = "10H";
		}
		else if (newCard == JACK_HEARTS) {
			hand[turn].nValue = 10;
			hand[turn].sName = "JH";
		}
		else if (newCard == QUEEN_HEARTS) {
			hand[turn].nValue = 10;
			hand[turn].sName = "QH";
		}
		else if (newCard == KING_HEARTS) {
			hand[turn].nValue = 10;
			hand[turn].sName = "KH";
		}
		else if (newCard == ACE_HEARTS) {
			hand[turn].nValue = 11;
			hand[turn].sName = "AH";
		}
		else if (newCard == TWO_DIAMONDS) {
			hand[turn].nValue = 2;
			hand[turn].sName = "2D";
		}
		else if (newCard == THREE_DIAMONDS) {
			hand[turn].nValue = 3;
			hand[turn].sName = "3D";
		}
		else if (newCard == FOUR_DIAMONDS) {
			hand[turn].nValue = 4;
			hand[turn].sName = "4D";
		}
		else if (newCard == FIVE_DIAMONDS) {
			hand[turn].nValue = 5;
			hand[turn].sName = "5D";
		}
		else if (newCard == SIX_DIAMONDS) {
			hand[turn].nValue = 6;
			hand[turn].sName = "6D";
		}
		else if (newCard == SEVEN_DIAMONDS) {
			hand[turn].nValue = 7;
			hand[turn].sName = "7D";
		}
		else if (newCard == EIGHT_DIAMONDS) {
			hand[turn].nValue = 8;
			hand[turn].sName = "8D";
		}
		else if (newCard == NINE_DIAMONDS) {
			hand[turn].nValue = 9;
			hand[turn].sName = "9D";
		}
		else if (newCard == TEN_DIAMONDS) {
			hand[turn].nValue = 10;
			hand[turn].sName = "10D";
		}
		else if (newCard == JACK_DIAMONDS) {
		}
	}

private:
	bool bCardDeck[52] = { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 };
	enum DECK_NUM { // order of suits _HEARTS, _DIAMONDS, _CLUBS, _SPADES
		NOCARD,
		TWO_HEARTS,
		THREE_HEARTS,
		FOUR_HEARTS,
		FIVE_HEARTS,
		SIX_HEARTS,
		SEVEN_HEARTS,
		EIGHT_HEARTS,
		NINE_HEARTS,
		TEN_HEARTS,
		JACK_HEARTS,
		QUEEN_HEARTS,
		KING_HEARTS,
		ACE_HEARTS,
		TWO_DIAMONDS,
		THREE_DIAMONDS,
		FOUR_DIAMONDS,
		FIVE_DIAMONDS,
		SIX_DIAMONDS,
		SEVEN_DIAMONDS,
		EIGHT_DIAMONDS,
		NINE_DIAMONDS,
		TEN_DIAMONDS,
		JACK_DIAMONDS,
		QUEEN_DIAMONDS,
		KING_DIAMONDS,
		ACE_DIAMONDS,
		TWO_CLUBS,
		THREE_CLUBS,
		FOUR_CLUBS,
		FIVE_CLUBS,
		SIX_CLUBS,
		SEVEN_CLUBS,
		EIGHT_CLUBS,
		NINE_CLUBS,
		TEN_CLUBS,
		JACK_CLUBS,
		QUEEN_CLUBS,
		KIND_CLUBS,
		ACE_CLUBS,
		TWO_SPADES,
		THREE_SPADES,
		FOUR_SPADES,
		FIVE_SPADES,
		SIX_SPADES,
		SEVEN_SPADES,
		EIGHT_SPADES,
		NINE_SPADES,
		TEN_SPADES,
		JACK_SPADES,
		QUEEN_SPADES,
		KING_SPADES,
		ACE_SPADES
	};
};

void GameOn() {
	blackjack bjo;
	bjo.BJGameOn();
}

int main(int argc, char* argv[])
{
	printf("BlackJack - ver 3a\n\n");
	blackjack bjo;
	srand((int)time(NULL));
	bool bQuit = false;
	while (!bQuit)
	{
		int nOption = 1;
		printf("1 - Deal Cards\t2 - Quit\nEnter: ");
		std::cin >> nOption; std::cout << std::endl << std::endl;

		if (nOption == 1)
			GameOn();
		else if (nOption == 2)
			bQuit = true;
		else
			printf("Invalid Entry...\n\n");
	}

	return 0;
}