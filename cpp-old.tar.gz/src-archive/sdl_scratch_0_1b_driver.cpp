/*******************************************************************************
	NULL;NULL;NULL;NULL;NULL;NULL;NULLNULL;NULL;NULL;NULL;NULL;NULL;NULL
*******************************************************************************/
#include <SDL.h>
#include <stdio.h>

int nSCREENWIDTH = 640;
int nSCREENHEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gWwindowSurface = NULL;
SDL_Surface* surf_mchar = NULL;
SDL_Surface* surf_floor = NULL;

bool initSDL();
bool loadMedia();
bool terminate();

int main(int argc, char* argv[])
{

}

bool initSDL()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize. SDL Error: %d\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		if (SDL_CreateWindow("SDL from Scratch - v1.0b", )
	}
}


//
//int main(int argc, char*argv[])
//{
//	SDL_Init(SDL_INIT_VIDEO);
//	printf("initialized SDL");
//
//	SDL_Delay(5000);
//	SDL_Quit;
//	return 0;
//}