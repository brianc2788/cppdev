//
//
// sdl true type font
//

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <iostream>
#include <string>

const int nSCREENW = 640;
const int nSCREENH = 480;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
TTF_Font* fontGlobal = NULL;
SDL_Texture* texture_ttf = NULL;

bool init();
bool loadMedia();

int main(int argc, char* pszargs[]) {

	SDL_Init(SDL_INIT_VIDEO);
	SDL_Quit();

	return 0;
}

bool init() {

	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("failed to initialize video. SDL Error: %s\n", SDL_GetError());
		return 0;
	}
	else {
		window = SDL_CreateWindow("SDL TTF demo", SDL_WINDOWPOS_UNDEFINED,
			SDL_WINDOWPOS_UNDEFINED, nSCREENW, nSCREENH,
			SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. SDL Error: %s\n", SDL_GetError());
			return 0;
		}
		else {
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL) {
				printf("failed to create renderer. SDL Error: %s\n", SDL_GetError());
				return 0;
			}
			else {
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);

				int imgFlags = IMG_INIT_PNG;
				
				if(!(IMG_Init(imgFlags) & imgFlags)) {
					printf("sdl_image could not initialize. IMG Error: %s\n", IMG_GetError());
					return 0;
				}
				
				if (TTF_Init() == -1) {
					printf("ttf could not initialize. ttf error: %s\n", TTF_GetError());
					return 0;
				}

				return 1;
			}
		}
	}
		
}

bool loadMedia() {
	fontGlobal = TTF_OpenFont("Ariel.ttf", 16);
	if (fontGlobal == NULL) {
		printf("failed to load font. TTF Error: %s\n", TTF_GetError());
		return 0;
	}
	else {
		SDL_Color textColor = { 0, 0, 0 };

		if (!texture_ttf.loadFromRenderedText("test text test text", textColor)) {
			printf("failed to render text texture.\n");
			return 0;
		}
		else {
			return 1;
		}
	}
}