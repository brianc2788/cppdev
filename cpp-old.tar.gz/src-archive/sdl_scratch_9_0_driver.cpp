/******************************************************************************
						SDL Scratch - v0.9
						Build 06042018
						typo: file name should be sdl_scratch_0_9. Not ...9_0

	Added next step from LazyFoo's tutorial. Adds more images to correspond
	with key presses.

	Moving the sprite to the middle and then up down left right according to
	key presses was from experimentation.
******************************************************************************/
#include <SDL.h>
#include <stdio.h>
#include <string>

// NEW
enum KeyPressSurfaces
{
	KEY_PRESS_SURFACE_DEFAULT,
	KEY_PRESS_SURFACE_UP,
	KEY_PRESS_SURFACE_DOWN,
	KEY_PRESS_SURFACE_LEFT,
	KEY_PRESS_SURFACE_RIGHT,
	KEY_PRESS_SURFACE_TOTAL
};

// global variables
const int nSCREEN_WIDTH = 640;
const int nSCREEN_HEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;

// global functions
bool init();
bool loadMedia();
void closeSDL();
// NEW
SDL_Surface* loadSurface(std::string path);
SDL_Surface* gKeyPressSurfaces[KEY_PRESS_SURFACE_TOTAL];
SDL_Surface* gCurrentSurface = NULL;


int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("Closing application in 3 seconds...\n");
		SDL_Delay(3000);
		exit(1);
	}
	else
	{
		if (!loadMedia())
		{
			printf("Closing application in 3 seconds...\n");
			SDL_Delay(3000);
			exit(1);
		}
		else
		{
			bool bUserQuit = false;
			SDL_Event event;
			SDL_Rect sdlrect = { 304, 224, 0, 0 };

			// set default current surface
			gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_DEFAULT];
			
			while (!bUserQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
					{
						bUserQuit = true;
					}
					// add key presses
					else if (event.type == SDL_KEYDOWN)
					{
						// select surfaces based on key press
						switch (event.key.keysym.sym)
						{
						case SDLK_UP:
							gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_UP];
							sdlrect = { 304, 192, 0, 0 };
							break;

						case SDLK_DOWN:
							gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_DOWN];
							sdlrect = { 304, 256, 0, 0 };
							break;

						case SDLK_LEFT:
							gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_LEFT];
							sdlrect = { 272, 224, 0, 0 };
							break;

						case SDLK_RIGHT:
							gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_RIGHT];
							sdlrect = { 336, 224, 0, 0 };
							break;

						default:
							gCurrentSurface = gKeyPressSurfaces[KEY_PRESS_SURFACE_DEFAULT];
							sdlrect = { 304, 224, 0, 0 };
							break;
						}
					}
				}
				
				SDL_BlitSurface(gCurrentSurface, NULL, gScreenSurface, &sdlrect);
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}
	return 0;
}

// NEW


SDL_Surface* loadSurface(std::string path)
{
	// load image located at path
	SDL_Surface* loadedSurface = SDL_LoadBMP(path.c_str());
	if (loadedSurface == NULL)
	{
		printf("Couldn't load image to surface. SDL Error: %s\n", SDL_GetError());
	}
	return loadedSurface;
}

bool init()
{
	bool bSuccess = true;

	printf("Initializing SDL and creating window...\n");
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Failed to initialize. SDL Error: %s\,", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("SDL Scratch - v0.9", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nSCREEN_WIDTH, nSCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("Failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	// load default surface
	gKeyPressSurfaces[KEY_PRESS_SURFACE_DEFAULT] = loadSurface("assets/NPC0.bmp");
	if (gKeyPressSurfaces[KEY_PRESS_SURFACE_DEFAULT] == NULL)
	{
		printf("Failed to load default image.\n");
		bSuccess = false;
	}

	// load UP surface
	gKeyPressSurfaces[KEY_PRESS_SURFACE_UP] = loadSurface("assets/NPC1.bmp");
	if (gKeyPressSurfaces[KEY_PRESS_SURFACE_UP] == NULL)
	{
		printf("Failed to load UP image.\n");
		bSuccess = false;
	}

	// load DOWN surface
	gKeyPressSurfaces[KEY_PRESS_SURFACE_DOWN] = loadSurface("assets/NPC2.bmp");
	if (gKeyPressSurfaces[KEY_PRESS_SURFACE_DOWN] == NULL)
	{
		printf("Failed to load DOWN image.\n");
		bSuccess = false;
	}

	// load LEFT image
	gKeyPressSurfaces[KEY_PRESS_SURFACE_LEFT] = loadSurface("assets/NPC3.bmp");
	if (gKeyPressSurfaces[KEY_PRESS_SURFACE_LEFT] == NULL)
	{
		printf("Failed to load LEFT image.\n");
		bSuccess = false;
	}

	// load RIGHT image
	gKeyPressSurfaces[KEY_PRESS_SURFACE_RIGHT] = loadSurface("assets/NPC4.bmp");
	if (gKeyPressSurfaces[KEY_PRESS_SURFACE_RIGHT] == NULL)
	{
		printf("Failed to load RIGHT image.\n");
		bSuccess = false;
	}

	return bSuccess;
}

void closeSDL()
{
	SDL_FreeSurface(gCurrentSurface);
	gCurrentSurface = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}