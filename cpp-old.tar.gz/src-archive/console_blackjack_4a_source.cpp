/*******************************************************************************
	Console Blackjack - ver 4a
	build 08182018

	in progress...
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <string>
#include <ctime>
using namespace std;

#define mydef(card) card = card + 1 || card = card + 2;
#define thing1 printf("hi\n");
void afunction()
{
	thing1
}

void GameOn();

int main(int argc, char* argv[])
{
	printf("CONSOLE BLACKJACK - VER 4A\n\n");

	bool bQuit = false;
	while (!bQuit)
	{
		unsigned int nOption;
		printf("1 - Deal\n2 - Quit\nEnter: ");
		cin >> nOption; cout << endl << endl;

		if (nOption == 1)
			afunction;
		else if (nOption == 2)
			bQuit = true;
		else
			printf("Invalid Entry...\n\n");
	}

	return 0;
}

void GameOn()
{

}