/*
	warm-up

	setting up and write SDL window from scratch

*/
#include <SDL.h>
#include <stdio.h>

// global vars
const int nScreenWidth = 640;
const int nScreenHeight = 480;

SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gCharacterBmap = NULL;

// global functs
bool initialize();
bool loadImage();
void terminate();

int main(int argc, char* argv[])
{
	initialize();
	loadImage();

	bool bQuit = false;
	SDL_Event sdlevent;

	while (!bQuit)
	{
		while (SDL_PollEvent(&sdlevent) != 0)
		{
			if (sdlevent.type == SDL_QUIT)
			{
				bQuit = true;
			}
		}

		SDL_Rect sdlrect = { 320,240,352,272 }; /* first 2 coordinates designate the upper-left corner of the rect. second two should be bottom-right; but seem to have no effect... */
		SDL_BlitSurface(gCharacterBmap, NULL, gScreenSurface, &sdlrect);
		SDL_UpdateWindowSurface(gWindow);
	}

	terminate();
	return 0;
}

bool initialize()
{
	bool success = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("initialization phase. SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("SDL from scratch - v0.5", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nScreenWidth, nScreenHeight, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("window creation phase. SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}
	return success;
}

bool loadImage()
{
	bool success = true;

	gCharacterBmap = SDL_LoadBMP("NPC1.bmp");
	if (gCharacterBmap == NULL)
	{
		printf("Couldn't load the image. SDL Error: %s\n", SDL_GetError());
		success = false;
	}

	return success;
}

void terminate()
{
	SDL_FreeSurface(gCharacterBmap);
	gCharacterBmap = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}