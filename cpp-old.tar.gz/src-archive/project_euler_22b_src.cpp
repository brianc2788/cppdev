/*******************************************************************************
	Project Euler - Problem 22 (b)
	Problem:
	Using names.txt (right click and 'Save Link/Target As...'), a 46K text file
	containing over five-thousand first names, begin by sorting it into
	alphabetical order. Then working out the alphabetical value for each name,
	multiply this value by its alphabetical position in the list to obtain a
	name score.
	For example, when the list is sorted into alphabetical order, COLIN, which
	s worth 3 + 15 + 12 + 9 + 14 = 53, is the 938th name in the list.
	So, COLIN would obtain a score of 938 � 53 = 49714.
	What is the total of all the name scores in the file?
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <fstream>
#include <string>

int main(int argc, char* argv[]) {
	//FILE file;
	std::fstream fileOut;
	fileOut.open("file.txt", std::ofstream::out);
	if (fileOut.is_open()) {
		fileOut << "test";
		fileOut.close();
	}
	else {
		printf("failed to create/open file.\n");
	}

	std::fstream fileIn;
	fileIn.open("file.txt");
	std::string contents;
	fileIn >> contents;

	std::cout << contents << std::endl;

	fileIn.close();

	getchar();
	return 0;
}