/*

	HANGMAN - Version 9.0.0
	Build 04232018

	rewrite using techniques to create and write directly to screen buffer.

*/
#include <stdio.h>
#include <string>
#include <Windows.h>

const int nScreenW = 50;
const int nScreenH = 50;
SMALL_RECT smrect = { 0,0,nScreenW,nScreenH };

wchar_t* pScreen = new wchar_t[nScreenW*nScreenH];
HANDLE hOriginal = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
DWORD dwBytesWritten = 0;
CONSOLE_FONT_INFOEX cfi;

int main(int argc, char* argv[]) {

	SetConsoleTitle(L"HANGMAN 9.0.0");
	SetConsoleTextAttribute(hConsole, 0x0070);
	SetConsoleWindowInfo(hConsole, TRUE, &smrect);
	SetConsoleScreenBufferSize(hConsole, { nScreenW, nScreenH });
	SetConsoleActiveScreenBuffer(hConsole);

	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = 16;
	cfi.dwFontSize.Y = 16;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	SetCurrentConsoleFontEx(hConsole, false, &cfi);

	for (int i = 0; i < nScreenW*nScreenH; i++) { pScreen[i] = ' '; }
	swprintf_s(&pScreen[100], 8, L"HANGMAN");
	WriteConsole(hConsole, pScreen, nScreenW*nScreenH, &dwBytesWritten, NULL);
	
	bool bRunning = TRUE;
	while (bRunning) {

		if (GetAsyncKeyState((unsigned char)'Q'))
			bRunning = FALSE;

	}

	CloseHandle(hConsole);

	return EXIT_SUCCESS;
}