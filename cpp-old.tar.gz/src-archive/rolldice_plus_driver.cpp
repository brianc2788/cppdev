/*******************************************************************************
							Roll Dice PLUS - v0.1

*******************************************************************************/
#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <ctime>
using namespace std;

int main(int argc, char* argv[]) {
	printf("::Roll Dice PLUS - 0.1::\n\n");
	srand(time(NULL));
	int nDiceIn, nOption;
	bool bQuit = false;

	while (!bQuit) {
		cout << "Roll how many dice? : ";
		cin >> nDiceIn; cout << endl;

		for (int n = 0; n < nDiceIn; n++) {
			printf("%d\n", ((rand() % 6) + 1));
		}

		cout << "1 - Roll again\n2 - Quit\nEnter: ";
		if (getchar() == '1') {
			bQuit = false;
		}
		else if (getchar() == '2') {
			bQuit = true;
		}
	}

	return 0;
}