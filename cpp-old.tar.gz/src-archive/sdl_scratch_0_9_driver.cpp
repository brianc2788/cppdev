/******************************************************************************
						SDL Scratch - v0.9
						Build 06092018

	next in the series. continuing the tutorial. bitmap load optimization.
******************************************************************************/
#include <SDL.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	const int nSCREEN_WIDTH = 640;
	const int nSCREEN_HEIGHT = 480;
	SDL_Window* gWindow = NULL;
	gWindow = SDL_CreateWindow("SDL Scratch - v0.9", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nSCREEN_WIDTH, nSCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	SDL_Surface* gScreenSurface = NULL;
	gScreenSurface = SDL_GetWindowSurface(gWindow);
	SDL_Surface* surf_player = NULL;
	surf_player = SDL_LoadBMP("assets/NPC0.bmp");
	SDL_Surface* surf_tile = NULL;
	surf_tile = SDL_LoadBMP("assets/floor32.bmp");
	int rectX = 0;
	int rectY = 0;
	SDL_Rect rect_tile = { rectX,rectY,0,0 };
	int playerposX = 304;
	int playerposY = 224;
	SDL_Rect rect_player = { playerposX, playerposY,  0, 0 };
	SDL_Event event;

	bool bUserQuit = false;
	while (!bUserQuit)
	{
		while (SDL_PollEvent(&event) != 0)
		{
			if (event.type == SDL_QUIT)
			{
				bUserQuit = true;
				break;
			}
			else if (event.key.keysym.sym == SDLK_UP && playerposY > 16)
			{
				playerposY -= 5;
				break;
			}
			else if (event.key.keysym.sym == SDLK_DOWN && playerposY < 464)
			{
				playerposY += 5;
				break;
			}
			else if (event.key.keysym.sym == SDLK_LEFT && playerposX > 16)
			{
				playerposX -= 5;
				break;
			}
			else if (event.key.keysym.sym == SDLK_RIGHT && playerposX < 624)
			{
				playerposX += 5;
				break;
			}
		}

		// draw floor
		for (int y = 0; y <= 15; y++)
		{
			for (int x = 0; x <= 20; x++)
			{
				SDL_BlitSurface(surf_tile, NULL, gScreenSurface, &rect_tile);
				rectX += 32;
			}
			rectY += 32;
		}

		// draw player
		SDL_BlitSurface(surf_player, NULL, gScreenSurface, &rect_player);

		SDL_UpdateWindowSurface(gWindow);
	}

	SDL_FreeSurface(surf_player);
	surf_player = NULL;
	SDL_FreeSurface(surf_tile);
	surf_tile = NULL;
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;
	
	return 0;
}