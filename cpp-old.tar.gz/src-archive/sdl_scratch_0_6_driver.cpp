/******************************************************************************
					SDL from scratch - v0.6
					Build 06032018

	Rewrite 'sdl from scratch' series of projects to inject originality
	into the code and strengthen neurological patterns/connections.

	Taken one step further; built a release version using Windows GUI
	without the addition of the console for a more user-friendly experience.

	Distribution: Theoretically, everything one would need to run the program
	is contained in the sdl_scratch_0_6/Release folder; including an assets
	folder and SDL2.dll. Compress(zip) the entire folder for distribution.
	Client should be able to extract .zip file to a folder and run from there.
	Portability without any type of installation is expected.
******************************************************************************/
#include <SDL.h>
#include <stdio.h>

// global vars
const int nScreenWidth = 640;
const int nScreenHeight = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gNPC1 = NULL;

// global functs
bool init();
bool loadMedia();
void closeSDL();

int main(int argc, char* argv[])
{
	printf("Initializing SDL systems and creating window...\n");
	if (!init())
	{
		SDL_Delay(5000);
		printf("Closing application...\n");
	}
	else
	{
		if (!loadMedia())
		{
			SDL_Delay(5000);
			printf("Closing application...\n");
		}
		else
		{
			bool bUserQuit = false;
			SDL_Event event;

			while (!bUserQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.type == SDL_QUIT)
					{
						bUserQuit = true;
					}
				}

				SDL_Rect SDLrect = { 304, 224, 0, 0 };						// half screen width/height, minus half width of bitmap (gNPC1; NPC1.bmp).
				SDL_BlitSurface(gNPC1, NULL, gScreenSurface, &SDLrect);
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}

	closeSDL();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("SDL from scratch - v0.6", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nScreenWidth, nScreenHeight, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}

	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	gNPC1 = SDL_LoadBMP("assets/NPC1.bmp");

	if (gNPC1 == NULL)
	{
		printf("SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	return bSuccess;
}

void closeSDL()
{
	SDL_FreeSurface(gNPC1);
	gNPC1 = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}