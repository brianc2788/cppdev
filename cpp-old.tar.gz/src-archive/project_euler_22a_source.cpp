/*******************************************************************************
	Project Euler - Problem 22 (ver a)
	build 08142018

	from: https://projecteuler.net/problem=22

	Using names.txt (right click and 'Save Link/Target As...'), a 46K text file
	containing over five-thousand first names, begin by sorting it into
	alphabetical order. Then working out the alphabetical value for each name,
	multiply this value by its alphabetical position in the list to obtain a
	name score.
	
	For example, when the list is sorted into alphabetical order, COLIN,
	which is worth 3 + 15 + 12 + 9 + 14 = 53, is the 938th name in the list.
	So, COLIN would obtain a score of 938 � 53 = 49714.

	What is the total of all the name scores in the file?

	8-14-2018: thinking about reformatting the text file to get rid of the
			   quotations and commas. is that cheating?
*******************************************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <list>
using namespace std;

string nArrayNames[5000];
int nArrayNameScore[5000];

void populateArrayNames();
void print(string const stringIn);

int main(int argc, char* argv[])
{
	string s1 = "string 1";
	string *ps = &s1;

	print(*ps);

	getchar();
	return 0;
}

void print(string const stringIn)
{
	printf("%s\n", stringIn);
}

//void reformatFile()
//{
//	ifstream fileOut;
//	char chNext;
//
//	fileOut.open("p022_names.txt", ifstream::in);
//
//	while (fileOut.is_open())
//	{
//		fileOut >> chNext;
//
//		cout << chNext << endl;
//	}
//
//	fileOut.close();
//}

void populateArrayNames()
{
	char cChar;
	string newname;
	ifstream fileIn;
	fileIn.open("p022_names.txt", istream::in);
}