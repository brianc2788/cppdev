/*

	rewrite of my original phone book concept.

	brianc
	created 2/7/2018
	last update 2/8/2018 - most features are functioning.
						   good file excersize.
						   still has alot of potential.
*/

#include <iostream>
#include <fstream>
#include <string>

void addContact();
void listContacts();
void editContact();
void delContact();

int main() {
	// intro
	std::cout << "\n=====================[X] Phone Book [X]=======================" << std::endl;

	bool quit = false;

	while (!quit) {
		// menu
		std::cout << "\n\t\t[X][X] MENU [X][X]";

		std::cout << "\nAdd contact - \"add\"\t\tList contacts - \"list\"" << std::endl
				  << "Edit contact - \"edit\"\t\t"	<< "Delete contact - \"delete\""
				  << "\nQuit program - \"quit\""	<< std::endl
			  	  << "\nEnter keyword: ";
		std::string menuOption;
		std::cin >> menuOption;

		// do the option
		if (menuOption == "add") {
			addContact();
			continue;
		}else if (menuOption == "list") {
			listContacts();
			continue;
		}else if (menuOption == "edit"){
			editContact();
			continue;
		}else if (menuOption == "delete") {
			delContact();
			continue;
		}else if (menuOption == "quit") {
			quit = true;
			continue;
		}else {
			std::cout << "\nInvalid option . . ." << std::endl;
			system("pause");
			continue;
		}

	}


	return 0;
}

void addContact() {
	// opening the file. set an idnum equal to the highest id number and append
	// to new contact line.
	std::fstream namesnumbers;
	namesnumbers.open("namesnumbers.txt", std::fstream::in);

	std::string tempstring; // judging by the fact that i needed this variable, i did something wrong... oh well. it works.
	int idNum = 0;
	while (namesnumbers) {
		idNum++;
		getline(namesnumbers, tempstring);
	}
	namesnumbers.close();
	

	namesnumbers.open("namesnumbers.txt", std::fstream::app);
	if (namesnumbers.is_open()) {

		std::cout << "\nReady to write in Phone Book . . ." << std::endl;
	}
	else {
		std::cout << "\nERROR - couldn't open file . . ." << std::endl;
	}
	
	std::string sFname;
	std::string sLname;
	std::string sNumber;
	std::string sNotes;

	namesnumbers << (idNum == 0 ? (idNum+1) : idNum) << " "; // inline if statement
	std::cout << "\nEnter first name: ";
	std::cin  >> sFname;
	namesnumbers << sFname << " ";
	std::cout << "\nEnter last name: ";
	std::cin  >> sLname;
	namesnumbers << sLname << " ";
	std::cout << "\nEnter phone number: ";
	std::cin >> sNumber;
	namesnumbers << sNumber << " ";
	std::cout << "\nEnter any notes: ";
	std::cin.ignore();
	getline(std::cin, sNotes);
	namesnumbers << sNotes << std::endl;

	namesnumbers.close();

	std::cout << "\n\t\t[X][X] GOT IT [X][X]" << std::endl;
}

void listContacts() { // add alphabetical order/groups
	system("clr");
	std::ifstream namesnumbers;
	namesnumbers.open("namesnumbers.txt", std::fstream::in);
	std::string contact;

	std::cout << "\n\t     [X][X] YOUR CONTACTS [X][X]\n\n";

	while (namesnumbers, getline(namesnumbers, contact)) {
		std::cout << contact << std::endl;
	}
}

void editContact() {
	std::string editName;
	std::cout << "\nEnter first and last name of contact you want to edit: ";
	std::cout << "\nUnder construction . . ." << std::endl;

}

void delContact() {
	// show contact list and user selects ID number
	std::ifstream namesnumbers;
	namesnumbers.open("namesnumbers.txt", std::ifstream::in);

	std::string lookupContacts;
	while (namesnumbers, getline(namesnumbers, lookupContacts)) {
		
		std::cout << lookupContacts << std::endl;
	}
	// re-open and output(?) to file i.e. delete entire entry linked to corresponding ID num.
	namesnumbers.open("namesnumbers.txt", std::ofstream::out);
	
	std::string selectContact;


	namesnumbers.close();
}