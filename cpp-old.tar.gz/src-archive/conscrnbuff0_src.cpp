/*******************************************************************************
	console screen buffer testing grounds
*******************************************************************************/
#include <cstdlib>
#include <stdio.h>
#include <Windows.h>
#include <iostream>

int SCREENWIDTH = 40;
int SCREENHEIGHT = 40;

int main(int argc, char* argv[]) {

	wchar_t* pScreen = new wchar_t[SCREENWIDTH*SCREENHEIGHT];
	for (int n = 0; n < (int)(SCREENWIDTH*SCREENHEIGHT); n++) { pScreen[n] = L' '; }
	HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
	DWORD dwBytesWritten = 0;

	SetConsoleTitle("custom screen buffer");
	SetConsoleScreenBufferSize(hConsole, { 40, 40 });
	
	if (!SetConsoleActiveScreenBuffer(hConsole)) {
		printf("failed to set console to new buffer.\n");
	}
	else {
		swprintf_s(&pScreen[40], 8, L"success");
	}

	system("PAUSE");
	return 0;
}