/*
	
	HANGMAN (DEMO) - version 8.0b

	latest attempt at hangman. keep giving up in the middle of the process...

	created 3/17/18 - about 45 mins in and we are up to drawing the hangman.
					  time to create the other logic.

			3:21am	- program finished. asks user to guess a letter, compares
					  the letter to the hidden word, and updates the number
					  of wrong guesses and the hangman string. if the user
					  guesses wrong 6 times and has produced the hangman's
					  entire body, the program outputs a losing message and
					  quits. if the user can enter all of the different letters
					  contained in the hidden word, the program outputs a
					  winning message and quits.

					  IN CONCLUSION...
					  i think i should leave this program as-is and create
					  a new project to write a better version of the game
					  and include randomly selected hidden words or a 2
					  player mode with user-generated hidden words.
					  might be a good oppertunity to exercise using a
					  seperate class file to draw from a much bigger list
					  of hidden words. but again, leave the code as-is
					  for future reference since this is the eighth or so
					  attempt at making this game and this is by far the
					  closest resemblence of it. for all intents and
					  purposes, this was a success.

					  FINAL THOUGHT
					  kind of a mess but that's all for now.

					  - added 'DEMO' to the in-game title. seems accurate.

*/

#include <iostream>
#include <iomanip>
#include <string>
#include <algorithm>	// for toupper()
using namespace std;

string sHangman; // 30 elements

void drawHangman();
void updateHangman(int nWrongGuesses);

int main() {

	cout << setw(6) << "HANGMAN DEMO - v8.0b" << endl << endl;

	sHangman += "  +--|";
	sHangman += "     |";
	sHangman += "     |";
	sHangman += "     |";
	sHangman += "======";

	string sHiddenWord[2] = { {"DOORKNOB"}, {"________"} };
	
	int nWrongGuesses = 0;

	bool bHangemHigh = false;

	while (!bHangemHigh) {

		drawHangman();

		cout << setw(6) << sHiddenWord[1] << endl << endl;

		char cLetterGuess;
		cout << "Guess a letter: ";
		cin >> cLetterGuess; cout << endl;

		bool bGoodGuess  = false;
		for (int x = 0; x < 8; x++) {
			if (toupper(cLetterGuess) == sHiddenWord[0][x]) { // toupper(cLetterGuess)
				sHiddenWord[1][x] = sHiddenWord[0][x];
				bGoodGuess = true;
			}
		}

		if (bGoodGuess == false)
			nWrongGuesses++;

		updateHangman(nWrongGuesses);

		if (nWrongGuesses == 6) {
			drawHangman();
			cout << "You Lose. x_x" << endl;
			cin.ignore();
			getchar();
			bHangemHigh = true;
		}

		if (sHiddenWord[0] == sHiddenWord[1]) {
			cout << sHiddenWord[1] << endl << "You Win!" << endl;
			cin.ignore();
			getchar();
			bHangemHigh = true;
		}
		
	}

	return 0;
}

void drawHangman() {

	

	cout << setw(12);

	for (int line = 0; line < 30; line++) {
		if (line % 6 != 0) {
			cout << sHangman[line];
		}
		else {
			cout << endl << setw(12) << sHangman[line];
		}
	}

	cout << endl << endl;

}

void updateHangman(int nWrongGuesses) {

	if (nWrongGuesses == 0) {			// reset sHangman (for debugging. was supposed to be for when starting a new game but...)
		sHangman[8] = ' ';
		sHangman[13] = ' ';
		sHangman[14] = ' ';
		sHangman[15] = ' ';
		sHangman[19] = ' ';
		sHangman[21] = ' ';
	}
	else if (nWrongGuesses == 1) {		// each value adds only one body part.
		sHangman[8] = 'O';
	}
	else if (nWrongGuesses == 2) {
		sHangman[14] = '|';
	}
	else if (nWrongGuesses == 3) {
		sHangman[13] = '/';
	}
	else if (nWrongGuesses == 4) {
		sHangman[15] = '\\';
	}
	else if (nWrongGuesses == 5) {
		sHangman[19] = '/';
	}
	else if (nWrongGuesses == 6) {
		sHangman[21] = '\\';
	}

}