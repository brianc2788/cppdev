//
// stage 3 - more events/keypresses.
// lazyfoo sdl tutorial goes on to add different surfaces to different keypresses.
// this is where i deviate from the source material and opt to add a background
// with a loop to a 32x32 bmp. added a controllable character onscreen.
// 
#include <stdio.h>
#include <SDL.h>

int SCREENWIDTH = 640;
int SCREENHEIGHT = 480;

SDL_Window* window = NULL;
SDL_Surface* surf_screen = NULL;
SDL_Surface* surf_floor32 = NULL;
SDL_Surface* surf_npc1 = NULL;

bool init();
bool loadMedia();
void close();

int main(int argc, char* argv[]) {
	bool bError = false;
	if (!init()) {
		printf("exiting...\n");
		bError = true;
	}
	else {
		if (!loadMedia()) {
			printf("exiting...\n");
			bError = true;
		}
		else {
			SDL_Rect rect_floor = { 0,0,32,32 };
			SDL_Rect rect_npc1 = { 308,224,32,32 };

			bool bQuit = false;
			SDL_Event event;
			while (!bQuit) {
				while (SDL_PollEvent(&event) > 0) {
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.key.keysym.sym == SDLK_w && rect_npc1.y > 0)
						rect_npc1.y -= 5;
					else if (event.key.keysym.sym == SDLK_s && rect_npc1.y < 448)
						rect_npc1.y += 5;
					else if (event.key.keysym.sym == SDLK_a && rect_npc1.x > 0)
						rect_npc1.x -= 5;
					else if (event.key.keysym.sym == SDLK_d && rect_npc1.x < 608 && event.type != SDL_KEYUP) // experimenting with left movement key.
						rect_npc1.x += 5;
				}

				rect_floor.x = 0; rect_floor.y = 0;
				for (int x = 0; x < 15; x++) {
					for (int y = 0; y < 20; y++) {
						SDL_BlitSurface(surf_floor32, NULL, surf_screen, &rect_floor);
						rect_floor.x += 32;
					}
					rect_floor.x = 0;
					rect_floor.y += 32;
				}

				SDL_BlitSurface(surf_npc1, NULL, surf_screen, &rect_npc1);
				SDL_UpdateWindowSurface(window);
			}
		}
	}

	if (bError)
		getchar();
	return 0;
}

bool init() {
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize SDL. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("lazyfoo sdl step 3", SDL_WINDOWPOS_UNDEFINED, \
			SDL_WINDOWPOS_UNDEFINED, SCREENWIDTH, \
			SCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			surf_screen = SDL_GetWindowSurface(window);
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;
	surf_npc1 = SDL_LoadBMP("assets/npc1.bmp");
	if (surf_npc1 == NULL) {
		printf("failed to load bitmap. %s\n", SDL_GetError());
		bSuccess = false;
	}
	surf_floor32 = SDL_LoadBMP("assets/floor32.bmp");
	if (surf_floor32 == NULL) {
		printf("failed to load bitmap. %s\n", SDL_GetError());
		bSuccess = false;
	}
	return bSuccess;
}

void close() {
	SDL_FreeSurface(surf_npc1);
	surf_npc1 = NULL;
	SDL_FreeSurface(surf_floor32);
	surf_floor32 = NULL;
	SDL_DestroyWindow(window);
	window = NULL;
	SDL_Quit();
}