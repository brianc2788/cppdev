/*******************************************************************************
	retrogame - 4
	build 08012018

	geometry rendering
*******************************************************************************/
#include <SDL.h>
#include <stdio.h>
#include <string>

const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Surface *surface = NULL;

int main(int argc, char* argv[])
{
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize SDL. %s\n", SDL_GetError());
	}
	else
	{
		window = SDL_CreateWindow("the square", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, \
								nSCREENWIDTH, nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (window == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
		}
		else
		{
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL)
			{
				printf("failed to create renderer. %s\n", SDL_GetError());
			}
			else
			{
				bool bQuit = false;
				SDL_Event event;
				SDL_Rect rect = { nSCREENWIDTH / 2, nSCREENHEIGHT / 2, 0, 0 };
				SDL_Rect rect1 = { 560, 400, 0, 0 };

				while (!bQuit)
				{
					while (SDL_PollEvent(&event) != 0)
					{
						if (event.type == SDL_QUIT)
							bQuit = true;
					}

					SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0xFF, 0xFF);
					SDL_RenderClear(renderer);
					SDL_RenderFillRect(renderer, &rect);

					SDL_Rect rPlayer = { 304, 224, 0, 0 };
					surface = SDL_LoadBMP("NPC1.bmp");
					SDL_BlitSurface(surface, NULL, NULL, &rPlayer);

					SDL_RenderPresent(renderer);
				}
			}
		}
	}
	SDL_Quit();
	return 0;
}