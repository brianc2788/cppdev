/******************************************************************************
	Project Euler - Problem 3

	From:
	https://projecteuler.net/problem=3

	"The prime factors of 13195 are 5, 7, 13 and 29.
	What is the largest prime factor of the number 600851475143?"
******************************************************************************/
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[])
{
	int nTarget1 = 13195;
	bool bPrime = false;

	for (int x = 2; x < nTarget1; x++)
	{

	}

	getchar();
	return 0;
}