/******************************************************************************
					SDL Scratch - v0.7
					Build 03062018

	Rewrite for the 'sdl scratch' series. reinforce neural patterns and
	connections. Original variables and functions.
	
	Tried to improve the standard output messages to the console are more
	informative and keep the developer better up-to-date to the instructions
	being carried out by the program.

	Also, the screen constantly updates whereas before i believe it was
	only updating when SDL_PollEvent queue wasn't empty. Unnoticable at this
	stage, however, would have imperatively had to have been fixed later on
	for a fully-functional application.

	No plans to create a Release build. The last iteration/version (sdl_scratch
	_0_6) was designed to be more user-friendly on the client-side of things
	(no console/developer debugging, Windows GUI only). For this build, the
	debugging perspective has taken priority.
******************************************************************************/
#include <SDL.h>
#include <stdio.h>

// global variables
const int nScreen_Width = 640;
const int nScreen_Height = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gNPC1 = NULL;

// global functions
bool init();
bool loadMedia();
void closeSDL();

int main(int argc, char* argv[])
{
	if (!init())
	{
		SDL_Delay(5000);
		printf("Closing application in 5 seconds...\n");
	}
	else
	{
		if (!loadMedia())
		{
			SDL_Delay(5000);
			printf("Closing application in 5 seconds...\n");
		}
		else
		{
			bool bUserQuit = false;
			SDL_Event SDLevent;

			while (!bUserQuit)
			{
				while (SDL_PollEvent(&SDLevent) != 0)
				{
					if (SDLevent.type == SDL_QUIT)
					{
						bUserQuit = true;
						printf("Polled quit event by user. Exiting application...\n");
					}
				}

				if (bUserQuit == true)
					break;

				SDL_Rect SDLrect = { 304, 224, 0, 0 };
				SDL_BlitSurface(gNPC1, NULL, gScreenSurface, &SDLrect);
				printf("Updating window surface...\n");
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}
	SDL_Delay(2000);
	closeSDL();
	return 0;
}

bool init()
{
	bool bSuccess = true;
	
	printf("Initializing SDL systems...\n");
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Failed to initialize SDL. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		printf("Success!!\nCreating window...\n");
		gWindow = SDL_CreateWindow("SDL Scratch - v0.7 - Build 03062018", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nScreen_Width, nScreen_Height, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("Failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			printf("Success!!\n");
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;
	printf("Loading bitmap to surface...\n");
	gNPC1 = SDL_LoadBMP("assets/NPC1.bmp");
	if (gNPC1 == NULL)
	{
		printf("Failed to load image to surface. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		printf("Success!!\n");
	}
	return bSuccess;
}

void closeSDL()
{
	SDL_FreeSurface(gNPC1);
	gNPC1 = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}