/*
	added another src file for neatness
*/
#include "hiddenWords.h"

hangman::hangman() {

}

hangman::~hangman() {

}

int hangman::getRandNum() {
	nRandNum = rand();
	return nRandNum;
}

string hangman::setHidWord()
{
	// this function is being designed to count the number of words in the hiddenwords.txt file
	// and then pick a random number no greater than the total number of words counted. an effort
	// to minimize future code editing.
	//
	// first count how many words in the text file (hidden word database)
	int nCounter = 0;
	string shidWord;

	file_read.open("hiddenwords.txt", ifstream::in);

	if (!file_read) {
		cerr << "error opening file. quitting program ..." << endl;
		exit(1);
	}

	while (file_read, getline(file_read, shidWord)) {
		nCounter++;
	}

	file_read.close();		// i thought this wasn't necessary because the termination of the while loop implies the file is no longer open?
							// but was unable to get all words in the file as a result without this...

	//
	// loop again but stop at random number. 

	file_read.open("hiddenwords.txt", ifstream::in);

	for (int x = 0; x < (getRandNum() % nCounter); x++)
		file_read >> shidWord;

	return shidWord;

}