/*																			 *|

	TF WORD COUNTER - version 1.0a_04052018

	created april 5th, 2018		by Bri Chi

	inspired by one of the labs assigned in class CS121 Computer Science
	at ECC North. open a text file designated by the user, open the file,
	count the words(strings minus white space) and return the result.

	update 4/6 - good enough.
				 upon further inspection, wasnt good enough at all.
				 a char array for the word buffer didnt work in different
				 formats. string works though. app only works the first time
				 throught; if the user restarts the loop, trying to open
				 any text file will result in a count of 0 or unhandled
				 exception...

*/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cstdio>
using namespace std;

class FileManager {
public:
	FileManager() {};
	~FileManager() {};

	void countWords(string file_name);
	int getCounter() { return nCounter; };
private:
	ifstream iFile;
	string cBuffer;
	int nCounter;
} fmanager;

void FileManager::countWords(string file_name) {

	nCounter = 0;

	iFile.open(file_name.c_str(), ifstream::in);

	if (!iFile.is_open()) {
		cerr << "error opening file. quitting application..." << endl;
		getchar();
		exit(1);
	}

	while (!iFile.eof()) {

		iFile >> cBuffer;

		//if (cBuffer != NULL)		// after cBuffer takes the last word in the file it resets back to NULL ('\0') [or at least the first element does... some leftover characters seem to get 'pushed bey
			nCounter++;

	}

}

int main (int argn, char* pszArgs[]){

	cout << "TF WORD COUNTER - version 1.0a_04052018" << endl << endl;

	FileManager* fman = &fmanager;
	string sFileName;
	char yn;
	bool bRunning = true;

	while (bRunning) {

		cout << "enter name of file: ";
		cin >> sFileName; cout << endl << endl;

		sFileName.append(".txt");

		fman->countWords(sFileName);

		int nWords = fman->getCounter();

		cout << "counted " << nWords << " words." << endl << endl;

		cout << "count another file? (y/n): ";
		cin >> yn; cout << endl;

		if (yn == 'n' || yn == 'N')
			bRunning = false;

		fman->~FileManager();

	}
	
	getchar();
	return 0;
}

