/*
	sdl2 on visual studio
	result:
	SUCCESSfully drew an image(bmp) to surface and updated, visibly, to the screen
	and successfully handle quit event (x-out).

	sidenote: regardless of the dimensions given to SDL_Rect; smaller or larger than
	the original bitmap's size in pixels, image stays the same size and in the same,
	upper-left position.
*/
#include <SDL.h>
#include <stdio.h>

// global variables
const int nScreenWidth = 640;
const int nScreenHeight = 480;

SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gNPC = NULL;

// global functions
bool init();
bool loadMedia();
void close_SDL();

int main(int argc, char* argv[])
{
	init();
	loadMedia();

	bool bQuit = false;
	SDL_Event event;

	while (!bQuit)
	{
		while (SDL_PollEvent(&event) != 0)
		{
			if (event.type == SDL_QUIT)
			{
				bQuit = true;
			}
		}

		SDL_Rect sdlrect = { 0,0,32,32 };
		SDL_BlitSurface(gNPC, NULL, gScreenSurface, &sdlrect);

		SDL_UpdateWindowSurface(gWindow);
	}

	close_SDL();
	return 0;
}

bool init()
{
	bool success = true;
	printf("Initializing SDL systems...");

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	else
	{
		printf("Creating window...");
		gWindow = SDL_CreateWindow("SDL from scratch - 0.4", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nScreenWidth, nScreenHeight, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("SDL Error: %s\n", SDL_GetError());
			success = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}
	return success;
}

bool loadMedia()
{
	bool success = true;
	printf("Loading image...");

	gNPC = SDL_LoadBMP("bitmaps/NPC1.bmp");
	if (gNPC == NULL)
	{
		printf("Failed. SDL Error: %s\n", SDL_GetError());
		success = false;
	}
	
	return success;
}

void close_SDL()
{
	SDL_FreeSurface(gNPC);
	gNPC = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}