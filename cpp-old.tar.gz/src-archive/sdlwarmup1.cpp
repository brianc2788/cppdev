//
// sdl from memory.
// CHANGES: input is handled differently than i usually have done in the past.
// user moves avatar with WASD keys but only on keypress down and not on release.
// this iteration also uses a switch for this instead of several elif statements.
//
#include <cstdlib>
#include <stdio.h>
#include <SDL.h>
#include <SDL_image.h>
#include <string>

int SCREENW = 640;
int SCREENH = 480;

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* tex_bgtile = NULL;
SDL_Texture* tex_mchar = NULL;

bool init();
bool loadMedia();
SDL_Texture* loadTexture(std::string img_path);
void close();

int main(int argc, char* argv[]) {
	if (!init()) {
		printf("init() has failed.\n");
	}
	else {
		if (!loadMedia()) {
			printf("loadMedia() has failed.\n");
		}
		else {
			bool bQuit = false;
			SDL_Event event;
			SDL_Rect rFloor = { 0, 0, 32, 32 };
			SDL_Rect rPlayer = { 304, 224, 32, 32 };

			while (!bQuit) {
				while (SDL_PollEvent(&event) != 0) {
					if (event.type == SDL_QUIT)
						bQuit = true;
					else if (event.type == SDL_KEYDOWN) {
						switch (event.key.keysym.sym) {
						case SDLK_w:
							if (rPlayer.y > 0)
								rPlayer.y -= 5;
						case SDLK_s:
							if (rPlayer.y < 448)
								rPlayer.y += 5;
						case SDLK_a:
							if (rPlayer.x > 0)
								rPlayer.x -= 5;
						case SDLK_d:
							if (rPlayer.x < 608)
								rPlayer.x += 5;
						}
					}

					SDL_RenderClear(renderer);
					for (int y = 0; y < 15; y++) {
						for (int x = 0; x < 20; x++) {
							SDL_RenderCopy(renderer, tex_bgtile, NULL, &rFloor);
							rFloor.x += 32;
						}
						rFloor.x = 0;
						rFloor.y += 32;
					}
					rFloor.x, rFloor.y = 0;

					SDL_RenderCopy(renderer, tex_mchar, NULL, &rPlayer);
					SDL_RenderPresent(renderer);
				}
			}
		}
	}

	return 0;
}

bool init() {
	bool bSuccess = true;
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize SDL subsystems. SDL error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("sdl warmup1", SDL_WINDOWPOS_UNDEFINED,
									SDL_WINDOWPOS_UNDEFINED, SCREENW,
									SCREENH, SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL) {
				printf("failed to create renderer. SDL error: %s\n", SDL_GetError());
				bSuccess = false;
			}
			else {
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags)) {
					printf("failed to initialize SDL image. IMG error: %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;
	tex_bgtile = loadTexture("assets/floor32.png");
	if (tex_bgtile == NULL) {
		printf("failed to load texture 'bgtile'.\n");
		bSuccess = false;
	}
	else {
		tex_mchar = loadTexture("assets/npc1.png");
		if (tex_mchar == NULL) {
			printf("failed to load texture 'tex_mchar'.\n");
			bSuccess = false;
		}
	}
	return bSuccess;
}

SDL_Texture* loadTexture(std::string img_path) {
	SDL_Surface* loadSurface = IMG_Load(img_path.c_str());
	if (loadSurface == NULL) {
		printf("failed to load surface. IMG Error: %s\n", IMG_GetError());
	}
	else {
		SDL_Texture* newTexture = SDL_CreateTextureFromSurface(renderer, loadSurface);
		if (newTexture == NULL) {
			printf("failed to create texture from surface. SDL error: %s\n", SDL_GetError());
			SDL_FreeSurface(loadSurface);
			loadSurface = NULL;
		}
		else {
			SDL_FreeSurface(loadSurface);
			loadSurface = NULL;
			return newTexture;
		}
	}
}

void close() {
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyTexture(tex_bgtile);
	SDL_DestroyTexture(tex_mchar);
	window = NULL;
	renderer = NULL;
	tex_bgtile = NULL;
	tex_mchar = NULL;

	IMG_Quit();
	SDL_Quit();
}