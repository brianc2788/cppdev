#include "bj_dealer.h"

DEALER::DEALER()
{
	srand((int)time(NULL));

	for (int x = 0; x <= 52; x++)
	{
		bDeck[x] = true;
	}
}