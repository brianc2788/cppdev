/******************************************************************************
					SDL Scratch - Version 0.8
						Build 03062018
	
	Continuing the SDL Scratch series until the neural patterns/connections
	are distinguished enough to fully exercise SDL to the maximum extent
	thus far.

	Completed 100% from memory and is 100% identical and functional as
	the last, correct iteration.

	Builds for Debug and Release available.

******************************************************************************/
#include <SDL.h>
#include <stdio.h>

// global variables
const int nSCREEN_WIDTH = 640;
const int nSCREEN_HEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gNPC1 = NULL;

// global functions
bool init();
bool loadMedia();
void closeSDL();

int main(int argc, char* argv[])
{
	printf("Initializing SDL systems and creating window...\n");
	if (!init())
	{
		printf("Closing application in 3 seconds...\n");
		SDL_Delay(3000);
	}
	else
	{
		printf("Loading media...\n");
		if (!loadMedia())
		{
			printf("Closing application in 3 seconds...\n");
			SDL_Delay(3000);
		}
		else
		{
			bool bUserQuit = false;
			SDL_Event SDLevent;

			while (!bUserQuit)
			{
				while (SDL_PollEvent(&SDLevent) != 0)
				{
					if (SDLevent.type == SDL_QUIT)
					{
						printf("User request quit. Exiting application...");
						bUserQuit = true;
					}
				}

				if (bUserQuit == true)
				{
					break;
				}

				SDL_Rect SDLrect = { 304, 224, 0, 0 };
				SDL_BlitSurface(gNPC1, NULL, gScreenSurface, &SDLrect);
				printf("Updating window surface...\n");
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}
	SDL_Delay(2000);
	closeSDL();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Failed to initialize SDL. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("SDL Scratch - v0.8, Build 03062018", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nSCREEN_WIDTH, nSCREEN_HEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("Failed to create window. SDL Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			gScreenSurface = SDL_GetWindowSurface(gWindow);
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	gNPC1 = SDL_LoadBMP("assets/NPC1.bmp");
	if (gNPC1 == NULL)
	{
		printf("Failed to load image to surface. SDL Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	return bSuccess;
}

void closeSDL()
{
	SDL_FreeSurface(gNPC1);
	gNPC1 = NULL;

	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_Quit();
}