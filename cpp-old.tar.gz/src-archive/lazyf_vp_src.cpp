//
// viewport tutorial from lazyfoo.net
//

#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

int SCREENW = 640;
int SCREENH = 480;

bool init();
bool loadMedia();
void close();
SDL_Texture* loadTexture(std::string path);

SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* texPNGimg = NULL;

int main(int argc, char* argv[]) {

	if (!init()) {
		printf("init() has failed.\n");
	}
	else {
		if (!loadMedia()) {
			printf("loadMedia() has failed.\n");
		}
		else {
			bool bQuit = false;
			SDL_Event event;

			while (!bQuit) {
				while (SDL_PollEvent(&event) != 0) {
					if (event.type == SDL_QUIT)
						bQuit = true;
				}

				// clear screen
				SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
				SDL_RenderClear(renderer);

				// init and render viewports.

				// top left viewport.
				SDL_Rect topleftvp = { 0, 0, SCREENW / 2, SCREENH / 2 };
				SDL_RenderSetViewport(renderer, &topleftvp);

				SDL_RenderCopy(renderer, texPNGimg, 0, 0);

				// top right vp.
				SDL_Rect toprightvp = { SCREENW / 2, 0, SCREENW / 2, SCREENH / 2 };
				SDL_RenderSetViewport(renderer, &toprightvp);

				SDL_RenderCopy(renderer, texPNGimg, 0, 0);

				// bottom vp.
				SDL_Rect bottomvp = { 0, SCREENH / 2, SCREENW, SCREENH / 2 };
				SDL_RenderSetViewport(renderer, &bottomvp);

				SDL_RenderCopy(renderer, texPNGimg, NULL, NULL);

				// update screen.
				SDL_RenderPresent(renderer);
			}
		}
	}

	close();

	return 0;
}

bool init() {
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("failed to initialize SDL. Error: %s\n", SDL_GetError());
		bSuccess = false;
	}
	else {
		window = SDL_CreateWindow("viewport tutorial", SDL_WINDOWPOS_UNDEFINED,
			SDL_WINDOWPOS_UNDEFINED, SCREENW, SCREENH,
			SDL_WINDOW_SHOWN);
		if (window == NULL) {
			printf("failed to create window. Error: %s\n", SDL_GetError());
			bSuccess = false;
		}
		else {
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			if (renderer == NULL) {
				printf("failed to create renderer. Error: %s\n", SDL_GetError());
				bSuccess = false;
			}
			else {
				int imgFlags = IMG_INIT_PNG;
				if (!(IMG_Init(imgFlags) & imgFlags)) {
					printf("failed to initialize SDL image. Error: %s\n", IMG_GetError());
					bSuccess = false;
				}
			}
		}
	}
	return bSuccess;
}

bool loadMedia() {
	bool bSuccess = true;

	texPNGimg = loadTexture("npc0.png");
	if (texPNGimg == NULL) {
		printf("failed to load texture from surface.\n");
		bSuccess = false;
	}

	return bSuccess;
}

SDL_Texture* loadTexture(std::string path) {
	SDL_Texture* finalTexture = NULL;
	SDL_Surface* loadSurface = IMG_Load(path.c_str());
	if (loadSurface == NULL) {
		printf("failed to load image \"%s\". Error: %s\n", path.c_str(), IMG_GetError());
	}
	else {
		finalTexture = SDL_CreateTextureFromSurface(renderer, loadSurface);
		if (finalTexture == NULL) {
			printf("failed to create texture from surface. Error: %s\n", SDL_GetError());
		}

		SDL_FreeSurface(loadSurface);
	}

	return finalTexture;
}

void close() {
	SDL_DestroyWindow(window);
	window = NULL;
	SDL_DestroyRenderer(renderer);
	renderer = NULL;

	SDL_DestroyTexture(texPNGimg);
	texPNGimg = NULL;

	IMG_Quit();
	SDL_Quit();
}