/*

	CTIMER - Version 4.5.1
	Build 04192018

	Now that application can create its own buffer in the console,
	add features.

*/
#include <stdio.h>
#include <ctime>
#include <Windows.h>

int nScreenWidth = 50;
int nScreenHeight = 50;

wchar_t* pScreen = new wchar_t[nScreenWidth*nScreenHeight];
HANDLE hConsole = CreateConsoleScreenBuffer(GENERIC_WRITE | GENERIC_READ, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
DWORD dwBytesWritten = 0;
SMALL_RECT srRect = { 0, 0, 50, 50 };

int main(int argc, char* argv[]) {

	for (int i = 0; i < nScreenWidth*nScreenHeight; i++) { pScreen[i] = L' '; };
	
	SetConsoleTitle("CTIMER 4.5.1");
	SetConsoleTextAttribute(hConsole, 0x0070);
	SetConsoleScreenBufferSize(hConsole, { 50, 50 });
	SetConsoleWindowInfo(hConsole, FALSE, &srRect);
	SetConsoleActiveScreenBuffer(hConsole);

	swprintf_s(&pScreen[0], 49, L"CTIMER 4.5.1");
	WriteConsole(hConsole, pScreen, nScreenWidth*nScreenHeight, &dwBytesWritten, NULL);

	bool bRunning = true;
	while (bRunning) {

		if (GetAsyncKeyState((unsigned char)'Q'))
			bRunning = false;

	}

	return 0;
}