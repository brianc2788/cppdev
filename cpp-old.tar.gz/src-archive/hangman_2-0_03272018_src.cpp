/*

	HANGMAN	-	Version 2.0 03272018

	hopefully, a more efficient hangman. store hidden word list in a text file to save memory.

	4-2-2018	-	project officially started. plan to finish before work today. just wanna
					recreate my old hangman program but add a seperate file for class(es)
					and data structures.

*/
#include "hiddenWords.h"

int main(int ArgNum, char * pszArgs[]) {		// apparently these parameters are for console applications?

	hangman hm;
	hangman *hm_ptr = &hm;
	srand(time(NULL));
	string sHiddenWord = hm_ptr->setHidWord();
	bool bRunning = 1;
	
	while (bRunning) {

		cout << sHiddenWord << endl;

		getchar();
		bRunning = 0;
	}

	// delete[] hm_ptr;		problems.
	
	return EXIT_SUCCESS;
}