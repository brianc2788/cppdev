/*******************************************************************************
	retro game - v3.0a

	using sdl image extension library, load png image and optimize surface.
	png format allows for use of the alpha channel to utilize image
	transparency.
*******************************************************************************/
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>

bool init();
bool loadMedia();
void term();
SDL_Surface* loadSurface(std::string img_path);

const int nSCREENWIDTH = 640;
const int nSCREENHEIGHT = 480;
SDL_Window* gWindow = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* surf_main_char = NULL;

int main(int argc, char* argv[])
{
	if (!init())
	{
		printf("init() has failed.\n");
	}
	else
	{
		if (!loadMedia())
		{
			printf("loadMedia() has failed\n");
		}
		else
		{
			bool bQuit = false;
			SDL_Event event;

			int playerposX = 304;
			int playerposY = 224;
			SDL_Rect player_rect = { playerposX, playerposY, 0, 0 };
			player_rect.w = 100;
			player_rect.h = 100;
			while (!bQuit)
			{
				while (SDL_PollEvent(&event) != 0)
				{
					if (event.key.keysym.sym == SDLK_UP && playerposY > 0)
					{
						playerposY -= 5;
					}
					else if (event.key.keysym.sym == SDLK_DOWN && playerposY < 448)
					{
						playerposY += 5;
					}
					else if (event.key.keysym.sym == SDLK_LEFT && playerposX > 0)
					{
						playerposX -= 5;
					}
					else if (event.key.keysym.sym == SDLK_RIGHT && playerposX < 608)
					{
						playerposX += 5;
					}
					else if (event.type == SDL_QUIT)
					{
						bQuit = true;
					}
				}
				
				player_rect = { playerposX, playerposY, NULL, NULL };
				SDL_BlitSurface(surf_main_char, NULL, gScreenSurface, &player_rect);
				SDL_UpdateWindowSurface(gWindow);

			}
		}
	}

	printf("exited main loop...\n");
	SDL_Delay(500);
	term();
	return 0;
}

bool init()
{
	bool bSuccess = true;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("failed to initialize. %s\n", SDL_GetError());
		bSuccess = false;
	}
	else
	{
		gWindow = SDL_CreateWindow("retro game - v3.0a", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, nSCREENWIDTH, nSCREENHEIGHT, SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("failed to create window. %s\n", SDL_GetError());
			bSuccess = false;
		}
		else
		{
			// INITIALIZE PNG LOADING
			int imgFlags = IMG_INIT_PNG;
			if (!IMG_Init(imgFlags) & imgFlags) // this funct returns successfully loaded img flags. needs to return the same img flag value, else error.
			{
				printf("failed to initialize SDL_image. IMG_GetError: %s\n", IMG_GetError());
				bSuccess = false;
			}
			else
			{
				gScreenSurface = SDL_GetWindowSurface(gWindow);
			}
		}
	}
	return bSuccess;
}

bool loadMedia()
{
	bool bSuccess = true;

	surf_main_char = loadSurface("assets/NPC4.png");
	if (surf_main_char == NULL)
	{
		printf("failed to load surface surf_mainchar. %s\n", SDL_GetError());
		bSuccess = false;
	}
	
	return bSuccess;
}

// updated surface loading for optimization and png img format. //
SDL_Surface* loadSurface(std::string img_path)
{
	SDL_Surface* opt_img = NULL;
	SDL_Surface* loadedImg = IMG_Load(img_path.c_str());
	if (loadedImg == NULL)
	{
		printf("failed to load image. %s\n", IMG_GetError());
	}
	else
	{
		// convert image to screen format
		opt_img = SDL_ConvertSurface(loadedImg, gScreenSurface->format, NULL);
		if (opt_img == NULL)
		{
			printf("failed to optimize image. %s\n", IMG_GetError());
		}

		// get rid of old loaded surface.
		SDL_FreeSurface(loadedImg);
	}

	return opt_img;
}

void term()
{
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	SDL_FreeSurface(surf_main_char);
	surf_main_char = NULL;

	SDL_Quit();
}