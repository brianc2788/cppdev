/*******************************************************************************
	Console Blackjack - v1a
	build 08162018

	blackjack using the windows console...
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <string>
#include <ctime>
using namespace std;

class BLACKJACK
{
public:
	BLACKJACK() {
		// init card deck to false
		for (int x = 0; x < 52; x++) {
			bCardsDealt[x] = false;
		}
		for (int x = 0; x < 10; x++) {
			nCardsHeld[0][x] = NOCARD;
		}
		for (int x = 0; x < 10; x++) {
			nCardsHeld[1][x] = NOCARD;
		}

		// constructor deals 2 cards to each player.
		nCardsHeld[0][0] = DrawCard();
		nCardsHeld[0][1] = DrawCard();
		nCardsHeld[1][0] = DrawCard();
		nCardsHeld[1][1] = DrawCard();
	}

	void printDealerHand() {
		printf("DEALER HAND:");
		for (int x = 0; x < 10; x++)
		{
			if (nCardsHeld[0][x] > NOCARD)
			printf("- %d ", nCardsHeld[0][x]);
		}
		printf("\n");
	}
	void printPlayerHand() {
		printf("PLAYER HAND:");
		for (int x = 0; x < 10; x++)
		{
			if (nCardsHeld[1][x] > NOCARD)
			printf("- %d ", nCardsHeld[1][x]);
		}
		printf("\n");
	}

private:
	int nCardsHeld[2][10];
	bool bCardsDealt[52];

	int DrawCard() {
		int newCard = ((rand() % 52) + 1);
		
		while (bCardsDealt[newCard] == true)
		{
			newCard = ((rand() % 52) + 1);
		}

		bCardsDealt[newCard] = true;
	
		return newCard;
	}

	enum CARDS // suit order: _HEARTS, _DIAMONDS, _CLUBS, _SPADES
	{
		NOCARD,
		TWO_HEARTS,
		THREE_HEARTS,
		FOUR_HEARTS,
		FIVE_HEARTS,
		SIX_HEARTS,
		SEVEN_HEARTS,
		EIGHT_HEARTS,
		NINE_HEARTS,
		TEN_HEARTS,
		JACK_HEARTS,
		QUEEN_HEARTS,
		KING_HEARTS,
		ACE_HEARTS,
		TWO_DIAMONDS,
		THREE_DIAMONDS,
		FOUR_DIAMONDS,
		FIVE_DIAMONDS,
		SIX_DIAMONDS,
		SEVEN_DIAMONDS,
		EIGHT_DIAMONDS,
		NINE_DIAMONDS,
		TEN_DIAMONDS,
		JACK_DIAMONDS,
		QUEEN_DIAMONDS,
		KIND_DIAMONDS,
		ACE_DIAMONDS,
		TWO_CLUBS,
		THREE_CLUBS,
		FOUR_CLUBS,
		FIVE_CLUBS,
		SIX_CLUBS,
		SEVEN_CLUBS,
		EIGHT_CLUBS,
		NINE_CLUBS,
		TEN_CLUBS,
		JACK_CLUBS,
		QUEEN_CLUBS,
		KING_CLUBS,
		ACE_CLUBS,
		TWO_SPADES,
		THREE_SPADES,
		FOUR_SPADES,
		FIVE_SPADES,
		SIX_SPADES,
		SEVEN_SPADES,
		EIGHT_SPADES,
		NINE_SPADES,
		TEN_SPADES,
		JACK_SPADES,
		QUEEN_SPADES,
		KING_SPADES,
		ACE_SPADES,
	};
};

void GameOn();

int main(int argc, char* argv[])
{
	printf("Blackjack 1a\n\n");
	srand((int)time(NULL));
	
	bool bQuit = false;

	while (!bQuit)
	{
		int nOption;
		printf("1 - Deal the cards\n2 - Quit\n\nEnter: ");
		std::cin >> nOption; std::cout << std::endl;

		if (nOption == 1)
			GameOn();
		else
			bQuit = true;
	}

	return 0;
}

void GameOn()
{
	BLACKJACK BJ;

	BJ.printDealerHand();
	BJ.printPlayerHand();

	printf("\n");
}