/*
	HANGMAN - v2.1 04032018

	fn around. discovered a way to make a sort of timer storing time(NULL) to a couple
	ints or doubles. initialize the first, wait for cin getchar, init the second.
	store the difference to a third variable, equal to the number of whole seconds that
	have passed...
*/

#include "hangman.h"

int main() {

	cout << "welcome to hangman v2.1 04032018" << endl << endl;

	bool bRunning = true;

	hmUtil util;

	long double t1 = time(NULL);
	getchar();
	long double t2 = time(NULL);
	double difference = t2-t1;
	while (bRunning) {

		cout << t1 << " " << t2 << endl;
		cout << difference << endl;
		getchar();
		bRunning = false;

	}
	cout << time(NULL) << endl;
	getchar();
	return EXIT_SUCCESS;
}