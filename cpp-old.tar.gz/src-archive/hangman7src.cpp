/*

	another hagman

*/

#include <iostream>
#include <iomanip>
using namespace std;

string sHangman;
char cHiddenWord[8] = { 'D','O','O','R','K','N','O','B' };
char cDisplayWord[sizeof(cHiddenWord)];

void displayHangman();

int main() {

	cout << setw(23) << "HANGMAN - ver b0.1" << endl << endl;

	char cLetterGuess;

	displayHangman();

	sHangman[11] = 'O';
	sHangman[18] = '/';
	sHangman[19] = '|';
	sHangman[20] = '\\';
	sHangman[26] = '/';
	sHangman[28] = '\\';

	displayHangman();

	getchar();
	return 0;
}

void displayHangman() {

	sHangman += "   +---|";
	sHangman += "       |";
	sHangman += "       |";
	sHangman += "       |";
	sHangman += "========";

	for (int x = 0; x < 40; x++) {
		if (x % 8 != 0) {
			cout << sHangman[x];
		}
		else {
			cout << endl << setw(12);
		}
	}
	cout << endl << endl << setw(6);

	cout << sizeof(cHiddenWord) << " " << sizeof(cHiddenWord) / sizeof(char) << " " << sizeof(char) << endl;

	for (int x = 0; x < sizeof(cHiddenWord)/sizeof(char); x++) {
		cout << "_" << setw(2);
	}

	cout << endl << endl;
}