/******************************************************************************
	Project Euler - Problem 05

	From: https://projecteuler.net/problem=5
	
	"2520 is the smallest number that can be divided by each of the numbers
	from 1 to 10 without any remainder.	What is the smallest positive number
	that is evenly divisible by all of the numbers from 1 to 20?"

	my answer: 232792560 (verified)

******************************************************************************/
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[])
{
	for (int x = 2; x < 3000000000; x++)
	{
		if (x % 2 == 0 && x % 3 == 0 && x % 4 == 0 && x % 5 == 0 && x % 6 == 00 && x % 7 == 0 && x % 8 == 0 && x % 9 == 0 && x % 10 == 0)
		{
			printf("Divisible by 1-10: %d\n", x);
			break;
		}
	}

	for (int x = 2; x < 3000000000; x++)
	{
		if (x % 2 == 0 && x % 3 == 0 && x % 4 == 0 && x % 5 == 0 && x % 6 == 00 && x % 7 == 0 && x % 8 == 0 && x % 9 == 0 && x % 10 == 0 && x % 11 == 0 && x % 12 == 0 && x % 13 == 0 && x % 14 == 0 && x % 15 == 0 && x % 16 == 0 && x % 17 == 0 && x % 18 == 0 && x % 19 == 0 && x % 20 == 0)
		{
			printf("Divisible by 1-20: %d\n", x);
			break;
		}
	}

	getchar();
	return 0;
}