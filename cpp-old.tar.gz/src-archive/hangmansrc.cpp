/*

	rewriite

*/
#include <iostream>
#include <iomanip>
using namespace std;

void showGameState();

int main(){

	showGameState();

	getchar();
	return 0;
}

char cHangman;

void showGameState(){

	cHangman += '   ';

}








///*
//
//	HANGMAN -- brianc -- 3/11/18
//
//	- start with 1 player, move on to two.
//	- 
//
//*/
//
//#include <iostream>
//#include <iomanip>
////#include <string>
//using namespace std;
//
//void displayHangman();
//
//char cHangman[5][12] = {
//	{"   +---+   "},
//	{"       |   "},
//	{"       |   "},
//	{"       |   "},
//	{"==========="}
//};
//
//int main() {
//
//	cout << setw(23) << "HANGMAN - ver b0.1" << endl << endl;
//
//	char hiddenWord[9] = "DOORKNOB";
//	char displayWord[16] = { "_ _ _ _ _ _ _ _" };
//	char cGuess;
//	
//	bool bGame = true;
//
//	while (bGame) {
//		displayHangman();
//		cout << setw(21) << displayWord << endl << endl;
//
//		cin >> cGuess; cout << endl;
//
//		if (cGuess )
//		cHangman[1][3] = 'o';
//
//	}
//
//	cin.ignore();
//	getchar();
//	return 0;
//}
//
//void displayHangman() {
//
//	for (int x = 0; x < 5; x++) {
//		cout << setw(10);
//		for (int y = 0; y < 12; y++) {
//
//			if (y % 12 != 0) {
//				cout << cHangman[x][y];
//			}
//			else {
//				cout << endl;
//			}
//		}
//	}
//	cout << endl << endl;
//}